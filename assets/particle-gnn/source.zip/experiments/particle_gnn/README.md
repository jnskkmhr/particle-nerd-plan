# Particle GNN experiment

This experiment learns 50 Hz sand-particle motion from Newton MPM recordings.
The current inference entry point predicts particles while replaying recorded box
motion. It does not yet integrate the analytical force estimator or advance the
box independently. No MPM solver runs during particle inference.

## Data collection

The scene contains rigid ground, sand, and one dynamic box, with no retaining
walls. The initial sand volume is 1 × 1 × 0.5 m; the MPM grid spacing is 0.04 m.
There are 16,384 particles, initially spaced 0.03125 m apart with random position
jitter up to 20% of that spacing. The box measures 0.12 × 0.12 × 0.08 m and its
mass varies uniformly from 5 to 10 kg.

Each episode contains initial settling followed by five seconds of recorded
interaction: 251 particle states at 50 Hz. Coupled MPM/MuJoCo Warp dynamics run at
200 Hz with a maximum of 25 MPM solver iterations and tolerance 1e-4.
The box is dynamic: sustained pushes and spring-based dragging apply forces and
torques, rather than setting the box pose directly.

`collect_campaign.py` defines 1,000 independent episode IDs and deterministic
random seeds. The motion distribution is 20% undisturbed, 40% sustained pushing,
and 40% continuous dragging. Episode hashes assign 776 training episodes,
109 validation episodes and 115 test episodes. Test episode 2 was inspected
during implementation checks and is excluded from final accuracy evaluation,
leaving 114 eligible test episodes. Retries preserve the split.
The accepted metadata records the actual seed, mass, filename and validation
results. A failed simulation is never silently substituted into the dataset.

Sand material is fixed: density 1600 kg/m³, Young's modulus 1e15 Pa, Poisson ratio
0.3, friction 0.48 and yield pressure 1e15 Pa. Tensile yield ratio, yield stress,
hardening, dilatancy and viscosity are zero. Varying material parameters or
particle spacing is outside the demonstrated training distribution.

## Model and training

The graph connects all particle pairs closer than 0.07 m. Three message-passing
layers use 64 hidden features. Warp constructs the graph and geometric features;
Torch evaluates and trains the network. Ground and box use the same geometry
encoder, with distance, surface normal, relative surface velocity, inverse mass
and friction. Body influence is zero beyond the neighborhood radius, before
particle messages propagate the influence through the material.

At time t, inputs are particle positions, three particle velocity states,
current box pose and velocity, material parameters, particle mass/radius and
time step. Stress and elastic deformation are not required. The model does not
receive the next box pose or next particle velocity.

The network predicts two three-component corrections for every particle:

```text
position_next = position + dt * (velocity + displacement_rate_correction)
velocity_next = velocity + endpoint_velocity_correction
dt = 0.02 seconds
```

Separate outputs distinguish displacement over a recording interval from the
velocity at its endpoint. Training uses individual reference transitions, with
0.0005 m/s Gaussian noise on velocity-history features, selected in a small
validation comparison against 0.005 m/s and zero noise. The loss includes all
particles and weights particles near the box and moving particles more strongly.
Checkpoint selection uses validation position errors for all particles, particles
near the box and moving particles. It never uses test episodes.

The first full experiment uses 10,000 AdamW updates on four GPUs, one full
particle graph per GPU per update. This is one-step training; its accuracy must
also be checked through recurrent rollouts using predicted particle states.

## Commands

From `/home/jkamohara/isaac/particle_nerd`, the local launcher uses the existing
IsaacLab/Newton environment without modifying the shared IsaacLab checkout:

```bash
bash experiments/particle_gnn/python.sh experiments/particle_gnn/play.py \
  --checkpoint /path/to/best.pt \
  --episode /path/to/episode-00002-attempt-0.hdf5
```

Add `--reference` to display the recorded MPM particles, or `--headless` to run
without a viewer. The box follows the same recorded trajectory in both modes.
The brown particles have a display radius of 0.012 m; this does not change their
simulation spacing or the MPM grid.

```bash
bash experiments/particle_gnn/python.sh experiments/particle_gnn/evaluate.py \
  --data /path/to/accepted-dataset \
  --checkpoint /path/to/best.pt \
  --output /path/to/evaluation --episodes 12 --steps 250

.venv-force/bin/python experiments/particle_gnn/summarize_campaign.py \
  /path/to/downloaded-metadata --output /path/to/audit.json --require-complete
```

OSMO submission commands and the pinned portable environment are documented in
`osmo/README.md`. Collection workflow `particle-gnn-collect-1` uses 32 independent
GPU workers in `isaac-lab-l40-07`.

## Interpretation of results

One-step errors compare predicted and reference positions of corresponding
particles over 20 ms. Five-second evaluations feed predicted particle states
back into the GNN and report error growth, ground penetration and graph overflow.
A frozen-particle baseline measures the error from keeping settled particles
stationary. Finite numerical states alone do not establish physical accuracy.

Inference keeps neighborhood construction, geometry and state updates on the GPU.
The network uses Torch. Explicit evaluation and recording transfer data to the
CPU outside the simulation step. CUDA graph capture is not enabled yet.
Reported particle-step timing excludes rendering, recording, rigid-body dynamics
and analytical contact-force estimation.

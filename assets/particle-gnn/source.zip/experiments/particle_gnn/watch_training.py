"""Publish live OSMO validation curves, then download completed training artifacts."""

import argparse
from datetime import datetime, timezone
import json
from pathlib import Path
import sys
import time

from probe_collection import probe
from watch_collection import run


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--workflow", required=True)
    parser.add_argument("--storage", required=True)
    args = parser.parse_args()
    root = Path(__file__).resolve().parents[2]
    site = root / "particle_nerd_plan"
    cache = site / "results/particle_gnn_full_training"
    (cache / "model").mkdir(parents=True, exist_ok=True)
    status_path = root / "experiments/particle_gnn/status.json"
    previous = None
    while True:
        query = run(
            ["osmo", "workflow", "query", args.workflow, "--format-type", "json"]
        )
        if query.returncode:
            print(
                json.dumps(dict(event="query_error", detail=query.stdout[-400:])),
                flush=True,
            )
            time.sleep(60)
            continue
        workflow = json.loads(query.stdout)
        (cache / "workflow.json").write_text(json.dumps(workflow, indent=2) + "\n")
        terminal = workflow["status"] not in ("PENDING", "RUNNING", "WAITING")
        tasks = [t for group in workflow["groups"] for t in group["tasks"]]
        if not terminal and any(t["status"] == "RUNNING" for t in tasks):
            metrics = probe(
                args.workflow,
                "train",
                "/osmo/data/output/model/metrics.jsonl",
                jsonlines=True,
            )
            if metrics:
                (cache / "model/metrics.jsonl").write_text(
                    "".join(json.dumps(row) + "\n" for row in metrics)
                )
        if terminal:
            transfer = run(
                ["osmo", "data", "download", args.storage, str(cache)], timeout=600
            )
            if transfer.returncode:
                print(
                    json.dumps(
                        dict(event="download_error", detail=transfer.stdout[-600:])
                    ),
                    flush=True,
                )
                return 1
        path = cache / "model/metrics.jsonl"
        metrics = (
            [json.loads(line) for line in path.read_text().splitlines()]
            if path.exists()
            else []
        )
        step = metrics[-1]["step"] if metrics else 0
        signature = (workflow["status"], step)
        print(
            json.dumps(
                dict(
                    event="training_status",
                    status=workflow["status"],
                    validation_step=step,
                )
            ),
            flush=True,
        )
        if signature != previous:
            if metrics:
                report = run(
                    [
                        sys.executable,
                        str(Path(__file__).with_name("training_report.py")),
                        str(cache),
                    ]
                )
                if report.returncode:
                    raise RuntimeError(report.stdout[-1000:])
            status = json.loads(status_path.read_text())
            status["updated_utc"] = datetime.now(timezone.utc).isoformat()
            status["stages"][2] = dict(
                stage="Training",
                status=f"{workflow['status']}: {args.workflow}",
                detail=f"Latest recorded validation: optimizer step {step:,} of 10,000. Training uses 776 episodes and checkpoint selection uses 109 separate validation episodes. See measured curves below.",
            )
            status_path.write_text(json.dumps(status, indent=2) + "\n")
            published = run(
                [
                    sys.executable,
                    str(Path(__file__).with_name("publish_progress.py")),
                    str(status_path),
                ]
            )
            if published.returncode:
                raise RuntimeError(published.stdout[-1000:])
            files = [
                "particle_gnn_development.html",
                "assets/particle-gnn/campaign-status.json",
                "assets/particle-gnn/source.zip",
            ]
            files += [
                f"assets/particle-gnn/{name}"
                for name in (
                    "training-curve.svg",
                    "training-metrics.json",
                    "gnn-evaluation.json",
                    "rollout-errors.svg",
                )
                if (site / "assets/particle-gnn" / name).exists()
            ]
            added = run(["git", "-C", str(site), "add", "--", *files])
            if added.returncode:
                raise RuntimeError(added.stdout[-1000:])
            commit = run(
                [
                    "git",
                    "-C",
                    str(site),
                    "commit",
                    "--only",
                    "-m",
                    f"Report GNN training: step {step}, {workflow['status']}",
                    "--",
                    *files,
                ]
            )
            if commit.returncode == 0:
                pushed = run(["git", "-C", str(site), "push", "origin", "main"])
                print(
                    json.dumps(
                        dict(event="website_push", returncode=pushed.returncode)
                    ),
                    flush=True,
                )
            previous = signature
        if terminal:
            return 0 if workflow["status"] == "COMPLETED" else 1
        time.sleep(60)


if __name__ == "__main__":
    sys.exit(main())

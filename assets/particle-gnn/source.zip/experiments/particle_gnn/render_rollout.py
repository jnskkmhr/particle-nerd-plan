"""Render matching Newton RTX views of MPM reference and recurrent GNN particles."""

import argparse
import json
from pathlib import Path
import subprocess
import sys

import h5py
from PIL import Image, ImageDraw, ImageFont


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--reference", type=Path, required=True)
    p.add_argument("--prediction", type=Path, required=True)
    p.add_argument("--work", type=Path, required=True)
    p.add_argument("--output", type=Path, required=True)
    args = p.parse_args()
    args.work.mkdir(parents=True, exist_ok=True)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with (
        h5py.File(args.reference) as reference,
        h5py.File(args.prediction) as predicted,
    ):
        start = int(predicted.attrs["start_frame"])
        valid = int(predicted.attrs["valid_frames"])
        manifest = json.loads(reference.attrs["manifest"])
        for name in ("reference", "prediction"):
            (args.work / f"{name}.json").write_text(json.dumps(manifest))
            with h5py.File(args.work / f"{name}.hdf5", "w") as out:
                out.create_dataset(
                    "particle_position",
                    data=reference["particle_position"][start : start + valid]
                    if name == "reference"
                    else predicted["particle_position"][:valid],
                    compression="lzf",
                )
                out.create_dataset(
                    "frame_steps", data=reference["frame_steps"][start : start + valid]
                )
                out.create_dataset("body_pose", data=reference["body_pose"][:])
    for name in ("reference", "prediction"):
        subprocess.run(
            [
                sys.executable,
                str(Path(__file__).with_name("render.py")),
                str(args.work),
                name,
                "--output",
                str(args.work / name),
            ],
            check=True,
        )
    output_frames = args.work / "combined"
    output_frames.mkdir(exist_ok=True)
    font = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf", 21)
    small = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf", 18)
    paths = sorted((args.work / "reference").glob("*.png"))
    for i, left in enumerate(paths):
        a = Image.open(left).convert("RGB")
        b = Image.open(args.work / "prediction" / left.name).convert("RGB")
        canvas = Image.new("RGB", (a.width + b.width, a.height + 90), (246, 248, 246))
        canvas.paste(a, (0, 0))
        canvas.paste(b, (a.width, 0))
        draw = ImageDraw.Draw(canvas)
        draw.text(
            (22, a.height + 10), "MPM reference particles", font=font, fill=(35, 55, 60)
        )
        draw.text(
            (a.width + 22, a.height + 10),
            "GNN particles — recurrent inference without MPM",
            font=font,
            fill=(35, 55, 60),
        )
        draw.text(
            (22, a.height + 45),
            f"{i * 0.04:.2f} s after settling | Same recorded box motion in both views | {manifest['body_mass_kg']:.2f} kg box | 0.04 m grid reference",
            font=small,
            fill=(50, 70, 75),
        )
        canvas.save(output_frames / left.name)
        if i == min(40, len(paths) - 1):
            canvas.save(args.output.with_suffix(".jpg"), quality=90)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    subprocess.run(
        [
            "ffmpeg",
            "-hide_banner",
            "-loglevel",
            "error",
            "-y",
            "-framerate",
            "25",
            "-i",
            str(output_frames / "%04d.png"),
            "-c:v",
            "libx264",
            "-crf",
            "21",
            "-pix_fmt",
            "yuv420p",
            "-movflags",
            "+faststart",
            str(args.output),
        ],
        check=True,
    )
    print("Saved", args.output)


if __name__ == "__main__":
    main()

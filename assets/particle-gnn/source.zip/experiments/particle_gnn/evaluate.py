"""Held-out one-step and recurrent particle rollout evaluation without MPM.

Box motion is replayed from reference data to isolate particle-model error.
This is explicitly not a closed-loop body-force or box-motion evaluation.
"""

import argparse
import json
from pathlib import Path
import time

import h5py
import numpy as np
import torch

from data import Episodes
from features import Features
from inference import ParticlePredictor
from model import ParticleGNN
from train import evaluate


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument("--data",type=Path,required=True)
    p.add_argument("--checkpoint",type=Path,required=True)
    p.add_argument("--output",type=Path,required=True)
    p.add_argument("--episodes",type=int,default=12)
    p.add_argument("--steps",type=int,default=250)
    args=p.parse_args()
    args.output.mkdir(parents=True,exist_ok=True)
    saved=torch.load(args.checkpoint,map_location="cuda",weights_only=False)
    model=ParticleGNN(**saved["config"]).cuda().eval();model.load_state_dict(saved["model"])
    episodes=Episodes(args.data,"test",model.config["history"])
    features=Features(16384,history=model.config["history"])
    one_step=evaluate(model,episodes,features,samples=48)
    del features,model
    rows=[]
    for record in episodes.records[:args.episodes]:
        with h5py.File(record["path"],"r") as f:
            manifest=json.loads(f.attrs["manifest"])
            steps=f["frame_steps"][:]
            start=int(np.searchsorted(steps,manifest["settled_step"]))
            stop=min(start+args.steps,len(steps)-1)
            predictor=ParticlePredictor(args.checkpoint,f["particle_position"][start],f["particle_velocity"][start],
                                       manifest,float(f["particle_mass"][0]),float(f["particle_radius"][0]))
            predictor.history.copy_(torch.as_tensor(np.concatenate([f["particle_velocity"][max(0,start-k)]
                for k in range(predictor.model.config["history"]-1,-1,-1)],axis=-1),device="cuda"))
            poses=torch.as_tensor(f["body_pose"][:],device="cuda")
            velocities=torch.as_tensor(f["body_velocity"][:],device="cuda")
            # Recording/evaluation synchronizes intentionally; predictor.step does not.
            positions=[predictor.x.cpu().numpy().copy()]
            errors=[];timings=[];failure=None
            with h5py.File(args.output/f"rollout-{record['index']:05d}.hdf5","w") as out:
                ds=out.create_dataset("particle_position",(stop-start+1,16384,3),dtype="f4",compression="lzf")
                ds[0]=positions[0]
                for i in range(start,stop):
                    begin,end=torch.cuda.Event(enable_timing=True),torch.cuda.Event(enable_timing=True)
                    begin.record()
                    predictor.step(poses[steps[i]],velocities[steps[i]])
                    end.record();end.synchronize()
                    timings.append(begin.elapsed_time(end))
                    diagnostic=predictor.diagnostics()
                    if diagnostic["graph_overflow"] or not diagnostic["finite"]:
                        failure=dict(frame=i-start+1,**diagnostic)
                        break
                    x=predictor.x.cpu().numpy()
                    ds[i-start+1]=x
                    errors.append(float(np.sqrt(np.mean(np.sum((x-f["particle_position"][i+1])**2,axis=-1)))))
                out.attrs["valid_frames"]=len(errors)+1
                out.attrs["reference_episode"]=record["index"]
                out.attrs["start_frame"]=start
                out.attrs["evaluation"]="MPM-free particles; reference rigid motion replay"
            row=dict(index=record["index"],case=record["case"],frames=len(errors),failure=failure,
                     position_rmse_m=errors,final_position_rmse_m=errors[-1] if errors else None,
                     median_step_ms=float(np.median(timings[3:])) if len(timings)>3 else None,
                     max_step_ms=float(max(timings)) if timings else None)
            rows.append(row)
            print(json.dumps({k:v for k,v in row.items() if k!="position_rmse_m"}),flush=True)
    result=dict(one_step=one_step,rollouts=rows,checkpoint_step=saved["step"],
                caveat="Box follows held-out MPM recording; these results do not establish coupled force or rigid-motion accuracy")
    (args.output/"evaluation.json").write_text(json.dumps(result,indent=2)+"\n")


if __name__=="__main__":main()

"""Publish the limited pilot noise comparison separately from full-data results."""

import json
from pathlib import Path
import re


def main():
    site = Path(__file__).resolve().parents[2] / "particle_nerd_plan"
    rows = []
    for name, noise in (
        ("particle_gnn_local_fit_check", 0.005),
        ("particle_gnn_local_fit_noise0005", 0.0005),
        ("particle_gnn_local_fit_noise0", 0.0),
    ):
        root = site / "results" / name
        metrics = [
            json.loads(line)
            for line in (root / "metrics.jsonl").read_text().splitlines()
        ]
        best = min(metrics, key=lambda r: r["checkpoint_selection_score_m"])
        rollout = json.loads((root / "validation_rollout/evaluation.json").read_text())[
            "rollouts"
        ][0]
        rows.append(
            dict(
                velocity_noise_m_s=noise,
                best_validation=best,
                rollout_final_rmse_m=rollout["final_position_rmse_m"],
                frozen_final_rmse_m=rollout["frozen_particle_final_position_rmse_m"],
            )
        )
    result = dict(
        training_episodes=[0, 1],
        validation_episodes=[8],
        optimizer_steps_per_run=2000,
        selected_noise_m_s=0.0005,
        caveat="Development comparison with two training episodes, not the full 1000-episode experiment",
        results=rows,
    )
    (site / "assets/particle-gnn/pilot-noise-validation.json").write_text(
        json.dumps(result, indent=2) + "\n"
    )
    table = "".join(
        f"<tr><td>{r['velocity_noise_m_s']:g}</td>"
        f"<td>{1000 * r['best_validation']['position_rmse_m']:.4f} mm</td>"
        f"<td>{1000 * r['best_validation']['near_box_position_rmse_m']:.4f} mm</td>"
        f"<td>{100 * r['rollout_final_rmse_m']:.2f} cm</td></tr>"
        for r in rows
    )
    content = f"""<section id="pilot-validation"><h2>Development check: training noise</h2>
<p><b>This is a two-training-episode pilot, not the 1,000-episode experiment.</b> Three runs use identical seeds, 2,000 optimizer updates and the same separate validation episode. Each checkpoint is selected by the same validation metric. The five-second evaluation uses predicted particle states and recorded box motion.</p>
<table><tr><th>Velocity noise [m/s]</th><th>One-step particle RMSE</th><th>One-step RMSE near box</th><th>Five-second particle RMSE</th></tr>{table}</table>
<p><b>Conclusion:</b> 0.0005 m/s performs better than 0.005 m/s in this pilot and is selected for the first full-data run. The pilot remains inadequate: constant velocity gives a one-step RMSE of 0.0063 mm, and keeping settled particles stationary gives a five-second RMSE of 0.80 cm. Lower one-step error does not by itself establish stable particle dynamics. The full-data experiment must be evaluated separately.</p>
<p class="small">Errors compare corresponding particle positions against MPM. The validation box undergoes sustained pushing. These results do not establish material or scene generalization. <a href="assets/particle-gnn/pilot-noise-validation.json">Exact pilot measurements</a></p></section>"""
    page = site / "particle_gnn_development.html"
    text = page.read_text()
    if '<section id="pilot-validation">' in text:
        text = re.sub(
            r'<section id="pilot-validation">.*?</section>',
            lambda _: content,
            text,
            count=1,
            flags=re.S,
        )
    else:
        text = text.replace(
            "<h2>Reference simulation and recording</h2>",
            content + "<h2>Reference simulation and recording</h2>",
        )
    page.write_text(text)


if __name__ == "__main__":
    main()

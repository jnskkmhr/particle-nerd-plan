#!/usr/bin/env bash
set -euo pipefail
TASK_CODE=/home/jkamohara/isaac/IsaacLab-particle-nerd
export OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 PYTHONUNBUFFERED=1
export PYTHONPATH="$TASK_CODE/examples/particle_nerd"
for package in "$TASK_CODE"/source/*; do
    if [[ -d "$package" ]]; then export PYTHONPATH="$PYTHONPATH:$package"; fi
done
exec /home/jkamohara/.local/bin/uv run --no-project \
 --python /home/jkamohara/isaac/IsaacLab/.venv/bin/python \
 --with numpy==2.4.6 --with usd-core --with h5py python "$@"

"""Publish the isolated eager/compiled pilot timing comparison."""

import json
from pathlib import Path
import re

import h5py
import numpy as np


def main():
    site = Path(__file__).resolve().parents[2] / "particle_nerd_plan"
    root = site / "results/particle_gnn_local_fit_noise0005"
    eager = json.loads(
        (root / "isolated_validation_rollout/evaluation.json").read_text()
    )["rollouts"][0]
    compiled = json.loads(
        (root / "compiled_validation_rollout/evaluation.json").read_text()
    )["rollouts"][0]
    with (
        h5py.File(root / "isolated_validation_rollout/rollout-00008.hdf5") as a,
        h5py.File(root / "compiled_validation_rollout/rollout-00008.hdf5") as b,
    ):
        difference = float(
            np.max(np.abs(a["particle_position"][1] - b["particle_position"][1]))
        )
        np.testing.assert_allclose(
            a["particle_position"][1], b["particle_position"][1], atol=2e-6, rtol=2e-5
        )
    result = dict(
        device="NVIDIA GeForce RTX 5090",
        particle_count=16384,
        episode=8,
        checkpoint="Pilot noise 0.0005, selected step 250",
        warmup_steps_excluded=3,
        eager_gpu_ms=eager["median_particle_step_gpu_ms"],
        eager_wall_ms=eager["median_particle_step_wall_ms"],
        compiled_gpu_ms=compiled["median_particle_step_gpu_ms"],
        compiled_wall_ms=compiled["median_particle_step_wall_ms"],
        gpu_speedup=eager["median_particle_step_gpu_ms"]
        / compiled["median_particle_step_gpu_ms"],
        first_step_max_position_difference_m=difference,
        scope="Particle graph, geometry, GNN and state update; excludes recording, rendering, rigid dynamics and analytical force estimation",
        model_quality="Pilot remains inaccurate; timing does not establish physical accuracy",
    )
    (site / "assets/particle-gnn/inference-compilation.json").write_text(
        json.dumps(result, indent=2) + "\n"
    )
    rows = "".join(
        f"<tr><td>{label}</td><td>{r['median_particle_step_gpu_ms']:.2f} ms</td><td>{r['median_particle_step_wall_ms']:.2f} ms</td></tr>"
        for label, r in (("Uncompiled Torch", eager), ("Compiled Torch", compiled))
    )
    content = f"""<section id="inference-timing"><h2>Local inference timing: optional Torch compilation</h2>
<p>Same pilot checkpoint and validation episode; 16,384 particles on one RTX 5090. Each run contains 250 particle steps. Medians exclude the first three steps, including initial compilation. No other experiment used the local GPU during these two timed runs.</p>
<table><tr><th>Network execution</th><th>GPU time per particle step</th><th>Wall time per particle step</th></tr>{rows}</table>
<p>The particle step includes Warp neighborhood construction, geometry features, GNN evaluation and particle state updates. It excludes rigid-body dynamics, analytical contact-force estimation, rendering and recording. First-step particle positions differ by at most {difference * 1e6:.2f} micrometers between the two implementations.</p>
<p><b>Conclusion:</b> optional network compilation reduces particle-step time by {result["gpu_speedup"]:.2f}× in this workload. It does not fix the pilot's prediction error. This is not a comparison against MPM, and full-solver CUDA graph capture is not enabled. Use <code>play.py --compile</code> to enable this path. <a href="assets/particle-gnn/inference-compilation.json">Measurements</a></p></section>"""
    page = site / "particle_gnn_development.html"
    text = page.read_text()
    if '<section id="inference-timing">' in text:
        text = re.sub(
            r'<section id="inference-timing">.*?</section>',
            lambda _: content,
            text,
            count=1,
            flags=re.S,
        )
    else:
        text = text.replace(
            "<h2>Reference simulation and recording</h2>",
            content + "<h2>Reference simulation and recording</h2>",
        )
    page.write_text(text)


if __name__ == "__main__":
    main()

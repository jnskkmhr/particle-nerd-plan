"""Render the recorded sample with Newton RTX; this does not resimulate it."""

import argparse
import json
from pathlib import Path

import h5py
import newton
import numpy as np
import warp as wp
from newton.viewer import ViewerRTX
from PIL import Image
from pxr import Gf, Sdf, UsdGeom, UsdShade


def bind_matte_materials(viewer, particle_path):
    for name, color in (("sand", (.32,.24,.21)), ("box", (.18,.20,.23))):
        path=f"/root/Materials/preview_{name}"
        material=UsdShade.Material.Define(viewer.stage,path)
        shader=UsdShade.Shader.Define(viewer.stage,path+"/Surface")
        shader.CreateIdAttr("UsdPreviewSurface")
        shader.CreateInput("diffuseColor",Sdf.ValueTypeNames.Color3f).Set(Gf.Vec3f(*color))
        shader.CreateInput("roughness",Sdf.ValueTypeNames.Float).Set(.8)
        shader.CreateInput("metallic",Sdf.ValueTypeNames.Float).Set(0.)
        material.CreateSurfaceOutput().ConnectToSource(shader.ConnectableAPI(),"surface")
        if name=="sand":
            prim=viewer.stage.GetPrimAtPath(particle_path)
            UsdShade.MaterialBindingAPI.Apply(prim).Bind(material)
            instancer=UsdGeom.PointInstancer(prim)
            for prototype in instancer.GetPrototypesRel().GetTargets():
                UsdShade.MaterialBindingAPI.Apply(viewer.stage.GetPrimAtPath(prototype)).Bind(material)
        else:
            for prim in viewer.stage.Traverse():
                if prim.IsA(UsdGeom.Mesh):
                    xyz=np.asarray(UsdGeom.Mesh(prim).GetPointsAttr().Get(0))
                    if len(xyz) and np.allclose(np.ptp(xyz,axis=0),[.12,.12,.08],atol=1e-5):
                        UsdShade.MaterialBindingAPI.Apply(prim).Bind(material)

p = argparse.ArgumentParser(description=__doc__)
p.add_argument("data", type=Path)
p.add_argument("case")
p.add_argument("--output", type=Path, required=True)
p.add_argument("--preview",action="store_true")
a = p.parse_args()
m = json.loads((a.data / f"{a.case}.json").read_text())
f = h5py.File(a.data / f"{a.case}.hdf5", "r")
wp.init()
b = newton.ModelBuilder()
b.add_ground_plane()
pose = f["body_pose"][0]
body = b.add_body(xform=wp.transform(pose[:3],pose[3:]),label="dynamic_box")
size=m["body_size_m"]
b.add_shape_box(body,hx=size[0]/2,hy=size[1]/2,hz=size[2]/2,color=(.32,.38,.42))
b.add_shape_box(body,xform=wp.transform(wp.vec3(.015,0,size[2]/2+.001),wp.quat_identity()),
                hx=.025,hy=.004,hz=.001,color=(.8,.8,.75))
model=b.finalize(device="cuda:0")
state=model.state()
viewer=ViewerRTX(width=960,height=640,headless=True,fps=25,environment="studio",async_rendering=False)
viewer.set_model(model)
viewer.set_camera(wp.vec3(1.8,-2.4,1.8))
viewer.camera.look_at((0.,0.,.18))
points=wp.array(f["particle_position"][0],dtype=wp.vec3,device=model.device)
colors=wp.array(np.tile([.32,.24,.21],(m["particle_count"],1)).astype("f4"),dtype=wp.vec3,device=model.device)
a.output.mkdir(parents=True,exist_ok=True)
frames=list(range(0,len(f["frame_steps"]),2))
if a.preview:
    frames=frames[:1]
for j,frame in enumerate(frames):
    step=int(f["frame_steps"][frame])
    state.body_q.assign(f["body_pose"][step:step+1])
    points.assign(f["particle_position"][frame])
    for _ in range(12 if j==0 else 2):
        viewer.begin_frame(step*m["dt"])
        viewer.log_state(state)
        # Display radius is independent of MPM collision/sampling radius.
        particle_path=viewer.log_points("sand",points,radii=.012,colors=colors)
        if j==0 and _==0:
            bind_matte_materials(viewer,particle_path)
        viewer.end_frame()
    Image.fromarray(viewer.get_frame().numpy()).save(a.output/f"{j:04d}.png")
    if j%25==0:
        print(a.case,j,len(frames),flush=True)
(a.output/"frames.json").write_text(json.dumps(dict(steps=[int(f["frame_steps"][i]) for i in frames],fps=25)))
viewer.close()
f.close()

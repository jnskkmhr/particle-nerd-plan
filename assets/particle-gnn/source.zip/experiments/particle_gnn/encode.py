"""Label RTX frames with simulation time and measured force; encode browser MP4."""

import argparse
import json
import subprocess
from pathlib import Path

import h5py
from PIL import Image, ImageDraw, ImageFont

p=argparse.ArgumentParser(description=__doc__)
p.add_argument("case")
a=p.parse_args()
root=Path(__file__).resolve().parents[2]
data=root/"particle_nerd_plan/results/particle_gnn_preview_v1"
assets=root/"particle_nerd_plan/assets/particle-gnn"
frames=data/"frames-final"/a.case
labelled=data/"frames-labelled"/a.case
labelled.mkdir(parents=True,exist_ok=True)
m=json.loads((data/f"{a.case}.json").read_text())
timeline=json.loads((frames/"frames.json").read_text())
font=ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf",18)
small=ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf",15)
with h5py.File(data/f"{a.case}.hdf5","r") as f:
    for index,step in enumerate(timeline["steps"]):
        original=Image.open(frames/f"{index:04d}.png").convert("RGB")
        image=Image.new("RGB",(original.width,original.height+90),(246,248,246))
        image.paste(original,(0,0))
        draw=ImageDraw.Draw(image)
        t=step*m["dt"]
        phase="initial settling" if step<m["settled_step"] else f"after settling: {t-m['settled_time_s']:.2f} s"
        draw.text((18,original.height+10),f"MPM reference | {a.case} | time {t:.2f} s | {phase}",font=font,fill=(35,55,60))
        force=f["material_on_body_wrench"][step-1,2] if step else 0.
        external=f["external_wrench"][step-1,2] if step else 0.
        draw.text((18,original.height+42),f"Sand on box Fz: {force:+.1f} N    External Fz: {external:+.1f} N    Box weight: 14.7 N",font=small,fill=(50,70,75))
        draw.text((18,original.height+65),"0.04 m MPM grid | 16,384 particles | no retaining walls | real-time playback",font=small,fill=(50,70,75))
        image.save(labelled/f"{index:04d}.png")
        if index==min(40,len(timeline["steps"])-1):
            image.save(assets/f"{a.case}-poster.jpg",quality=90)
subprocess.run(["ffmpeg","-hide_banner","-loglevel","error","-y","-framerate","25","-i",str(labelled/"%04d.png"),
                "-c:v","libx264","-crf","20","-pix_fmt","yuv420p","-movflags","+faststart",str(assets/f"{a.case}.mp4")],check=True)
print("Encoded",a.case)

"""Publish the completed dataset audit and its measured mass/motion distribution."""

import json
from pathlib import Path
import re

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np


def main():
    site = Path(__file__).resolve().parents[2] / "particle_nerd_plan"
    audit = json.loads((site / "results/particle_gnn_campaign_audit.json").read_text())
    assert audit["complete"] and audit["completed"] == 1000
    records = [json.loads(path.read_text()) for path in (site / "results/particle_gnn_campaign_accepted_metadata").rglob("*.campaign.json")]
    assets = site / "assets/particle-gnn"
    (assets / "dataset-audit.json").write_text(json.dumps(audit, indent=2) + "\n")
    fig, axes = plt.subplots(1, 2, figsize=(10, 3.4), layout="constrained")
    axes[0].hist([r["mass_kg"] for r in records], bins=np.linspace(5, 10, 11), color="#377d74", edgecolor="white")
    axes[0].set(xlabel="Dynamic box mass [kg]", ylabel="Accepted episodes")
    axes[1].bar(["Undisturbed", "Sustained push", "Continuous drag"], [audit["cases"][k] for k in ("rest", "long-push", "continuous-drag")], color="#52748b")
    axes[1].set_ylabel("Accepted episodes")
    for ax in axes:
        ax.grid(axis="y", alpha=0.2)
        ax.set_axisbelow(True)
    path = assets / "dataset-distribution.svg"
    fig.savefig(path)
    plt.close(fig)
    path.write_text("\n".join(line.rstrip() for line in path.read_text().splitlines()) + "\n")
    content = f'''<section id="dataset-audit"><h2>Completed dataset: 1,000 accepted episodes</h2>
<p>All 32 OSMO collection workers completed. An independent metadata audit found exactly one accepted record for each episode ID 0–999 and verified every seed, mass, motion type and train/validation/test assignment against the campaign specification. No simulation seed required a retry.</p>
<table><tr><th>Measured quantity</th><th>Result</th></tr>
<tr><td>Episode split</td><td>776 training, 109 validation, 115 test; test episode 2 is excluded from final accuracy reporting because it was inspected during development</td></tr>
<tr><td>Post-settlement records</td><td>251 states per episode at 50 Hz; 250,000 transitions over 1,000 five-second interactions</td></tr>
<tr><td>Records including initial settling</td><td>{audit['total_particle_frames']:,} particle states, with 16,384 positions and velocities per state</td></tr>
<tr><td>Stored HDF5 bytes</td><td>{audit['stored_bytes']/1e9:.2f} GB ({audit['stored_bytes']/2**30:.2f} GiB), excluding small metadata and logs</td></tr>
<tr><td>Observed box mass range</td><td>{audit['mass_min_kg']:.3f}–{audit['mass_max_kg']:.3f} kg</td></tr></table>
<img src="assets/particle-gnn/dataset-distribution.svg" alt="Recorded box masses and motion counts in the completed dataset">
<p><b>Force-recording limitation:</b> {audit['episodes_with_unaccounted_body_force_over_0_01_N']} episodes have a translational box-force residual above 0.01 N when only sand feedback, applied disturbances and gravity are included. Direct rigid-ground contact is not recorded as a separate force. Episode 456 was inspected: its largest residual coincides with the box contacting rigid ground outside the sand pile. These records remain valid particle-motion targets; the residual must not be interpreted as sand force.</p>
<p class="small"><a href="assets/particle-gnn/dataset-audit.json">Complete audit and metadata fingerprint</a>. The dataset remains in the authorized OSMO storage; this page publishes measurements and selected visualizations.</p></section>'''
    page = site / "particle_gnn_development.html"
    text = page.read_text()
    if '<section id="dataset-audit">' in text:
        text = re.sub(r'<section id="dataset-audit">.*?</section>', lambda _: content, text, count=1, flags=re.S)
    else:
        text = text.replace('<section id="pilot-validation">', content + '<section id="pilot-validation">')
    page.write_text(text)


if __name__ == "__main__":
    main()

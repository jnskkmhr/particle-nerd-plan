"""Publish measured training and rollout results without conflating replay and coupling."""

import argparse
import html
import json
from pathlib import Path
import re

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("run", type=Path)
    args = p.parse_args()
    site = Path(__file__).resolve().parents[2] / "particle_nerd_plan"
    assets = site / "assets/particle-gnn"
    # Periodic OSMO checkpoints may also remain under model/model/.
    # Prefer the final output (or current live cache) at the documented path.
    canonical = args.run / "model/metrics.jsonl"
    files = [canonical] if canonical.exists() else list(args.run.rglob("metrics.jsonl"))
    if len(files) != 1:
        raise ValueError(f"Expected one metrics file, found {len(files)}")
    rows = [
        json.loads(line) for line in files[0].read_text().splitlines() if line.strip()
    ]
    if not rows:
        raise ValueError("No measured training metrics yet")
    fig, axes = plt.subplots(2, 1, figsize=(9, 6), sharex=True, layout="constrained")
    steps = [r["step"] for r in rows]
    axes[0].plot(steps, [r["train_loss"] for r in rows], color="#267c72")
    axes[0].set_ylabel("Training loss, first GPU [(m/s)²]")
    for key, label in (
        ("position_rmse_m", "All particles"),
        ("near_box_position_rmse_m", "Near box"),
        ("moving_particle_position_rmse_m", "Moving particles"),
        ("constant_velocity_position_rmse_m", "Constant velocity baseline"),
        ("constant_velocity_near_box_position_rmse_m", "Constant velocity: near box"),
        (
            "constant_velocity_moving_particle_position_rmse_m",
            "Constant velocity: moving",
        ),
    ):
        axes[1].plot(
            steps,
            [1000 * r[key] if r.get(key) is not None else float("nan") for r in rows],
            label=label,
            linestyle="--" if key.startswith("constant_velocity") else "-",
        )
    axes[1].set_ylabel("Held-out one-step position RMSE [mm]")
    axes[1].set_xlabel("Optimizer step")
    axes[1].legend(fontsize=8)
    for ax in axes:
        ax.grid(alpha=0.2)
    path = assets / "training-curve.svg"
    fig.savefig(path)
    plt.close(fig)
    path.write_text(
        "\n".join(line.rstrip() for line in path.read_text().splitlines()) + "\n"
    )
    (assets / "training-metrics.json").write_text(json.dumps(rows, indent=2) + "\n")
    latest = rows[-1]
    content = f"""<section id="training-results"><h2>Measured GNN results</h2>
<p>Latest measured optimizer step: <b>{latest["step"]:,}</b>. Validation episodes are separate from training episodes. The plotted position error is a one-step error over20ms; it does not establish long-rollout stability.</p>
<img src="assets/particle-gnn/training-curve.svg" alt="Training loss and held-out particle prediction errors"><p><a href="assets/particle-gnn/training-metrics.json">Training metrics</a></p>"""
    evaluations = list(args.run.rglob("evaluation.json"))
    if evaluations:
        if len(evaluations) != 1:
            raise ValueError("Ambiguous evaluation result")
        evaluation = json.loads(evaluations[0].read_text())
        (assets / "gnn-evaluation.json").write_text(
            json.dumps(evaluation, indent=2) + "\n"
        )
        fig, ax = plt.subplots(figsize=(9, 5), layout="constrained")
        table = []
        for r in evaluation["rollouts"]:
            ax.plot(
                [0.02 * (i + 1) for i in range(len(r["position_rmse_m"]))],
                [100 * v for v in r["position_rmse_m"]],
                label=f"{r['index']}: {r['case']}",
            )
            error = (
                f"{100 * r['final_position_rmse_m']:.2f} cm"
                if r["final_position_rmse_m"] is not None
                else "No valid step"
            )
            baseline = (
                f"{100 * r['frozen_particle_final_position_rmse_m']:.2f} cm"
                if r["frozen_particle_final_position_rmse_m"] is not None
                else "—"
            )
            table.append(
                f"<tr><td>{r['index']}</td><td>{html.escape(r['case'])}</td><td>{r['frames'] * 0.02:.2f} s</td><td>{error}</td><td>{baseline}</td><td>{100 * r['max_fraction_below_ground_by_more_than_grid']:.3f}%</td><td>{'Failed' if r['failure'] else 'Finite'}</td></tr>"
            )
        ax.set_xlabel("Time after box settling [s]")
        ax.set_ylabel("Recurrent particle position RMSE [cm]")
        ax.legend(fontsize=7, ncol=2)
        ax.grid(alpha=0.2)
        path = assets / "rollout-errors.svg"
        fig.savefig(path)
        plt.close(fig)
        path.write_text(
            "\n".join(line.rstrip() for line in path.read_text().splitlines()) + "\n"
        )
        content += (
            """<h3>Held-out recurrent particle rollouts</h3><p>The GNN starts from reference particle state and then uses its own predicted states for250steps (5s), unless diagnostics stop the rollout. Box motion is replayed from the held-out MPM trajectory. MPM does not advance the predicted particles. This test isolates particle prediction; it is not a closed-loop body-force test.</p><img src="assets/particle-gnn/rollout-errors.svg" alt="Particle position error over recurrent rollouts"><div class="scroll"><table><tr><th>Episode</th><th>Motion</th><th>Evaluated duration</th><th>Final GNN error</th><th>Frozen-particle baseline</th><th>Largest fraction below ground by&gt;0.04m</th><th>State check</th></tr>"""
            + "".join(table)
            + """</table></div><p class="small">A finite rollout can still be inaccurate. The frozen baseline holds particles at their settled positions. Ground violation counts particle centers more than0.04m below the rigid ground. All RMSE values compare corresponding particle IDs, not rendered appearance.</p><p><a href="assets/particle-gnn/gnn-evaluation.json">Complete held-out evaluation</a></p>"""
        )
        displaced_rows = []
        for row in evaluation["rollouts"]:
            if "reference_displaced_particle_count_final" not in row:
                continue
            error = row["displaced_particle_final_position_rmse_m"]
            baseline = row["frozen_displaced_particle_final_position_rmse_m"]
            error_text = f"{100 * error:.2f} cm" if error is not None else "—"
            baseline_text = f"{100 * baseline:.2f} cm" if baseline is not None else "—"
            displaced_rows.append(
                f"<tr><td>{row['index']}</td><td>{row['reference_displaced_particle_count_final']:,}</td><td>{error_text}</td><td>{baseline_text}</td></tr>"
            )
        if displaced_rows:
            content += (
                "<details><summary>Errors on particles displaced by more than 1 cm in MPM</summary>"
                "<p>This subset is selected from reference displacement relative to the settled particle positions, at the final evaluated time. It focuses on material deformation rather than stationary particles.</p>"
                "<table><tr><th>Episode</th><th>Displaced particles</th><th>GNN RMSE</th><th>Frozen-particle baseline</th></tr>"
                + "".join(displaced_rows)
                + "</table></details>"
            )
    content += "</section>"
    content = (
        content.replace("over20ms", "over 20 ms")
        .replace("for250steps (5s)", "for 250 steps (5 s)")
        .replace("by&gt;0.04m", "by &gt; 0.04 m")
        .replace("than0.04m", "than 0.04 m")
    )
    page = site / "particle_gnn_development.html"
    text = page.read_text()
    if '<section id="training-results">' in text:
        text = re.sub(
            r'<section id="training-results">.*?</section>',
            lambda _: content,
            text,
            count=1,
            flags=re.S,
        )
    else:
        text = text.replace(
            "<h2>Reference simulation and recording</h2>",
            content + "<h2>Reference simulation and recording</h2>",
        )
    page.write_text(text)
    print(f"Published metrics through step {latest['step']}")


if __name__ == "__main__":
    main()

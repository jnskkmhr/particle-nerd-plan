"""Publish measured final training results, comparison videos, and local replay instructions."""

import argparse
import html
import json
from pathlib import Path
import re

import numpy as np


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("run", type=Path)
    args = p.parse_args()
    site = Path(__file__).resolve().parents[2] / "particle_nerd_plan"
    assets = site / "assets/particle-gnn"
    files = list(args.run.rglob("evaluation.json"))
    if len(files) != 1:
        raise ValueError("Expected one complete held-out evaluation")
    evaluation = json.loads(files[0].read_text())
    rows = evaluation["rollouts"]
    complete = [r for r in rows if r["failure"] is None and r["frames"] == 250]
    wins = sum(
        r["final_position_rmse_m"] < r["frozen_particle_final_position_rmse_m"]
        for r in complete
    )
    median = (
        float(np.median([r["final_position_rmse_m"] for r in complete]))
        if complete
        else None
    )
    baseline = (
        float(np.median([r["frozen_particle_final_position_rmse_m"] for r in complete]))
        if complete
        else None
    )
    if wins == len(rows) and len(complete) == len(rows):
        conclusion = "The GNN improves on keeping the sand stationary in all tested five-second rollouts. These tests cover one sand material and one box geometry; they do not establish coupled rigid-body accuracy."
    else:
        conclusion = "The current GNN is not yet a reliable replacement for MPM. Completing a rollout without numerical failure does not imply accurate sand motion. The frozen-particle comparison below tests whether predicted deformation improves on leaving the settled sand stationary."
    one = evaluation["one_step"]
    section = f"""<section id="trained-model"><h2>Trained model: held-out motion and local inference</h2>
<p><b>Conclusion:</b> {conclusion}</p>
<p>Training completed 10,000 optimizer updates on four NVIDIA L40 GPUs. Validation selected the checkpoint at update <b>{evaluation["checkpoint_step"]:,}</b>. Test episodes were excluded from training and checkpoint selection. Episode 2 was inspected during development and is also excluded from these results.</p>
<table><tr><th>Measurement</th><th>Result</th></tr>
<tr><td>Held-out one-step transitions, from distinct episodes</td><td>{evaluation["one_step"]["transitions"]}</td></tr>
<tr><td>One-step particle position RMSE, 20 ms</td><td>{1000 * one["position_rmse_m"]:.4f} mm; constant-velocity baseline {1000 * one["constant_velocity_position_rmse_m"]:.4f} mm</td></tr>
<tr><td>Complete five-second recurrent rollouts</td><td>{len(complete)} / {len(rows)}</td></tr>
<tr><td>Rollouts with lower final error than stationary sand</td><td>{wins} / {len(complete)} complete rollouts</td></tr>"""
    if complete:
        section += f"<tr><td>Median final particle position RMSE</td><td>GNN {100 * median:.2f} cm; frozen-particle baseline {100 * baseline:.2f} cm</td></tr>"
    section += """</table><p>The one-step test starts each prediction from recorded MPM particle states. The recurrent test starts once from recorded states, then feeds predicted particle states back into the GNN for 250 steps. Both tests receive the current recorded box pose and velocity. No future box state or future particle state enters the model.</p>
<p><b>Scope:</b> the GNN advances the particles without MPM. The box follows its recorded trajectory in these comparisons. The new model has not yet been coupled to the analytical force estimator, so these videos do not demonstrate independent box motion or interactive dragging.</p>"""
    descriptions = {
        288: "Sustained pushing",
        352: "Continuous dragging",
        800: "Rest after settling",
    }
    for index, title in descriptions.items():
        row = next(r for r in rows if r["index"] == index)
        filename = f"gnn-test-{index:05d}"
        for suffix in ("mp4", "jpg"):
            if not (assets / f"{filename}.{suffix}").is_file():
                raise FileNotFoundError(assets / f"{filename}.{suffix}")
        section += f"""<h3>{html.escape(title)} — held-out episode {index}</h3>
<video controls preload="metadata" poster="assets/particle-gnn/{filename}.jpg"><source src="assets/particle-gnn/{filename}.mp4" type="video/mp4"></video>
<p class="small">Left: MPM reference sand. Right: recurrent GNN sand. Both show the same recorded box motion. Evaluated duration {row["frames"] * 0.02:.2f} s; final GNN particle position RMSE {100 * row["final_position_rmse_m"]:.2f} cm; frozen-particle baseline {100 * row["frozen_particle_final_position_rmse_m"]:.2f} cm.</p>"""
    section += """<h3>Run the downloaded model locally</h3>
<p>The default launch below displays recurrent GNN particles with the held-out continuous-drag box recording. Add <code>--reference</code> to show the corresponding MPM recording, or <code>--headless</code> to check execution without a viewer. Torch compilation occurs on the first model call.</p>
<pre><code>cd /home/jkamohara/isaac/particle_nerd
bash experiments/particle_gnn/play_trained.sh</code></pre>
<p><a href="assets/particle-gnn/trained-model.pt">Selected checkpoint</a> · <a href="assets/particle-gnn/gnn-evaluation.json">Complete held-out metrics</a> · <a href="assets/particle-gnn/source.zip">Code and instructions</a></p>
<p class="small">Model inputs are current particle positions, three particle velocity states, current box pose and velocity, rigid-surface geometry, material parameters, particle mass and radius, and the time step. Materials and particle spacing are fixed in this dataset. Warp handles GPU neighborhoods, geometry and state updates; Torch evaluates the GNN.</p></section>"""
    page = site / "particle_gnn_development.html"
    text = page.read_text()
    if '<section id="trained-model">' in text:
        text = re.sub(
            r'<section id="trained-model">.*?</section>',
            lambda _: section,
            text,
            count=1,
            flags=re.S,
        )
    else:
        text = text.replace(
            '<section id="campaign-status">',
            section + '<section id="campaign-status">',
            1,
        )
    text = re.sub(
        r'<p class="note"><b>Stage:.*?</p>',
        '<p class="note"><b>Collection and initial GNN training completed.</b> The new comparison videos below show held-out recurrent GNN predictions alongside MPM reference particles. The earlier scene-preview videos use MPM throughout.</p>',
        text,
        count=1,
        flags=re.S,
    )
    page.write_text(text)
    print(
        json.dumps(
            dict(
                complete_rollouts=len(complete),
                rollout_count=len(rows),
                wins_against_frozen=wins,
                median_final_rmse_m=median,
                median_frozen_rmse_m=baseline,
            )
        )
    )


if __name__ == "__main__":
    main()

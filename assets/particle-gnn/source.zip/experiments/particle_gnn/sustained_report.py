"""Validate sustained disturbances independently and publish motion/force plots."""

import json
from pathlib import Path

import h5py
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
from scipy.spatial.transform import Rotation

ROOT = Path(__file__).resolve().parents[2]
DATA = ROOT / "particle_nerd_plan/results/particle_gnn_preview_v1"
ASSETS = ROOT / "particle_nerd_plan/assets/particle-gnn"
results = []
sections = []
initial = None
for case, title in (("long-push", "Sustained push with changing direction"),
                    ("continuous-drag", "Continuous dragging around a curved path")):
    for mass in (5, 10):
        name = f"{case}-{mass}kg"
        m = json.loads((DATA / f"{name}.json").read_text())
        p = m["sustained_interaction"]
        with h5py.File(DATA / f"{name}.hdf5", "r") as f:
            state = [f[key][0] for key in ("particle_position", "particle_velocity", "body_pose", "body_velocity")]
            if initial is None:
                initial = state
            else:
                for actual, reference in zip(state, initial, strict=True):
                    np.testing.assert_array_equal(actual, reference)
            for key in f:
                for start in range(0, len(f[key]), 16):
                    assert np.isfinite(f[key][start:start+16]).all(), (name, key)
            q, v, t = (f[key][:] for key in ("body_pose", "body_velocity", "time_s"))
            external, applied, current = (f[key][:] for key in
                ("external_wrench", "applied_feedback_wrench", "material_on_body_wrench"))
            settled = m["settled_step"]
            frame_steps = f["frame_steps"][:]
            assert np.all(np.diff(frame_steps) == 4)
            assert np.count_nonzero(frame_steps >= settled) == 251
            np.testing.assert_allclose(np.linalg.norm(q[:, 3:], axis=1), 1., atol=2e-6)
            np.testing.assert_allclose(np.diff(t), m["dt"], atol=1e-10)
            np.testing.assert_allclose(applied[1:], current[:-1], atol=.003, rtol=1e-4)
            expected = np.zeros_like(external)
            origin = q[settled, :3] + Rotation.from_quat(q[settled, 3:]).apply(p["anchor_local_m"])
            for step in range(settled, len(external)):
                post_t = (step-settled)*m["dt"]
                begin, end = p["active_interval_s"]
                if not begin <= post_t < end:
                    continue
                elapsed = post_t-begin
                envelope = min(1., elapsed/p["ramp_s"], (end-post_t)/p["ramp_s"])
                if case == "long-push":
                    angle = 2*np.pi*elapsed/p["push_turn_period_s"]
                    expected[step, :2] = envelope*(p["push_force_weight_fraction"]*mass*9.81*np.array([np.cos(angle), np.sin(angle)])
                        - p["push_damping_per_mass_per_s"]*mass*v[step, :2])
                    expected[step, 2] = -envelope*p["downward_force_weight_fraction"]*mass*9.81
                else:
                    angle = 2*np.pi*elapsed/p["drag_turn_period_s"]
                    offset = np.array([p["drag_radius_x_m"]*np.sin(angle),
                        p["drag_radius_y_m"]*(1-np.cos(angle)),
                        p["drag_vertical_offset_m"]+p["drag_vertical_amplitude_m"]*np.sin(2*angle)])
                    arm = Rotation.from_quat(q[step, 3:]).apply(p["anchor_local_m"])
                    point_v = v[step, :3]+np.cross(v[step, 3:], arm)
                    force = mass*(p["drag_stiffness_per_mass_per_s2"]*(origin+offset-q[step, :3]-arm)
                        - p["drag_damping_per_mass_per_s"]*point_v)
                    limit = p["drag_force_limit_weight_fraction"]*mass*9.81
                    force *= envelope*min(1., limit/max(np.linalg.norm(force), 1e-12))
                    expected[step, :3] = force
                    expected[step, 3:] = np.cross(arm, force)
            np.testing.assert_allclose(external, expected, atol=3e-4, rtol=2e-5)
            residual = mass*np.diff(v[:, :3], axis=0)/m["dt"]-applied[:, :3]-external[:, :3]-[0., 0., -mass*9.81]
            max_residual = float(np.linalg.norm(residual, axis=1).max())
            assert max_residual < .01, (name, "unaccounted body force", max_residual)
            assert m["max_fraction_particle_centers_below_ground_by_more_than_grid"] == 0.
            post = q[settled:, :3]
            result = dict(name=name, mass_kg=mass,
                horizontal_box_path_length_m=float(np.linalg.norm(np.diff(post[:, :2], axis=0), axis=1).sum()),
                max_horizontal_box_displacement_m=float(np.linalg.norm(post[:, :2]-post[0, :2], axis=1).max()),
                max_box_speed_m_s=float(np.linalg.norm(v[settled:, :3], axis=1).max()),
                max_box_angular_speed_rad_s=float(np.linalg.norm(v[settled:, 3:], axis=1).max()),
                max_force_balance_residual_N=max_residual,
                all_states_finite=True, force_schedule_verified=True,
                active_schedule_duration_s=p["active_interval_s"][1]-p["active_interval_s"][0])
            results.append(result)
            (ASSETS/f"{name}.json").write_text(json.dumps(dict(manifest=m, measurements=result), indent=2)+"\n")
            fig, axs = plt.subplots(3, 1, figsize=(10, 8), sharex=True, layout="constrained")
            for k, label in enumerate(("Fx", "Fy", "Fz")):
                axs[0].plot(t[:-1]-m["settled_time_s"], external[:, k], label=label, lw=1)
                axs[1].plot(t[:-1]-m["settled_time_s"], current[:, k], label=label, lw=1)
                axs[2].plot(t-m["settled_time_s"], q[:, k], label=("Box center x", "Box center y", "Box center z")[k])
            for ax in axs:
                ax.axvspan(*p["active_interval_s"], color="#deece6", alpha=.5, zorder=-1)
                ax.set_xlim(0, 5)
                ax.grid(alpha=.2)
                ax.legend(ncol=3, fontsize=8, loc="upper right")
            axs[0].set_ylabel("External force on box [N]")
            axs[1].set_ylabel("Sand force on box [N]")
            axs[2].set_ylabel("Box center position [m]")
            axs[2].set_xlabel("Time after box settling [s]")
            fig.suptitle(f"{title}: {mass} kg")
            svg = ASSETS/f"{name}-forces.svg"
            fig.savefig(svg)
            plt.close(fig)
            svg.write_text("\n".join(line.rstrip() for line in svg.read_text().splitlines())+"\n")
            np.savetxt(ASSETS/f"{name}-forces.csv", np.column_stack((t[:-1], external, current, applied)), delimiter=",",
                header="time_since_release_s,"+",".join(f"{prefix}_{c}" for prefix in ("external", "current_sand", "applied_sand") for c in ("Fx_N", "Fy_N", "Fz_N", "Tx_Nm", "Ty_Nm", "Tz_Nm")), comments="")
        sections.append(f'''<h3>{title}: {mass} kg</h3>
<video controls playsinline preload="metadata" poster="assets/particle-gnn/{name}-poster.jpg"><source src="assets/particle-gnn/{name}.mp4" type="video/mp4"></video>
<p>During the five seconds after settling, the box center travels <b>{result['horizontal_box_path_length_m']:.2f} m</b> horizontally along its path; its maximum horizontal distance from its settled position is <b>{result['max_horizontal_box_displacement_m']:.2f} m</b>. Peak box speed: {result['max_box_speed_m_s']:.2f} m/s; peak angular speed: {result['max_box_angular_speed_rad_s']:.2f} rad/s.</p>
<details><summary>Applied forces, sand contact force and box motion</summary><img src="assets/particle-gnn/{name}-forces.svg" alt="External and sand contact forces on the box and its position during sustained interaction"></details>
<p class="small">Shaded interval: commanded interaction. Force components use world axes; box-center z is measured above rigid ground. Force-balance residual is at most {max_residual:.2g} N. <a href="assets/particle-gnn/{name}.json">Settings and validation</a> · <a href="assets/particle-gnn/{name}-forces.csv">200 Hz force records</a></p>''')

fragment = '''<section id="sustained-motion"><h2>Longer pushes and continuous dragging: 5 and 10 kg</h2>
<p><b>Each disturbance lasts 4.65 seconds</b>, from 0.25 to 4.90 s after settling, with 0.20 s ramps. All four examples use the same initial particles and box pose/velocity (seed 41001), the 1 × 1 × 0.5 m initial sand volume, and a 0.04 m MPM grid. The rigid ground has no retaining walls.</p>
<ul><li><b>Sustained push:</b> the horizontal force direction turns through one full revolution. The drive magnitude is 90% of box weight, with velocity damping and an additional downward force of 20% of box weight. Forces act at the box center.</li>
<li><b>Continuous drag:</b> a spring pulls an off-center box point toward a moving target. The target follows a curved horizontal path with modest vertical variation, completing a revolution every 3 s. The force is capped at 2.5 times box weight; the off-center force also applies torque. Box position and velocity are determined by the coupled dynamics.</li></ul>
<p>The videos include initial settling followed by the full five-second interaction window. These are MPM reference simulations. Every recorded state was checked for finite values, every applied disturbance was independently reconstructed, and translational box force balance was checked using applied sand feedback, external force and gravity. No particle center moved more than one grid spacing below the rigid ground.</p>
''' + "\n".join(sections) + "</section>"
(DATA/"sustained-section.html").write_text(fragment)
(ASSETS/"sustained-summary.json").write_text(json.dumps(results, indent=2)+"\n")
print(json.dumps(results, indent=2))

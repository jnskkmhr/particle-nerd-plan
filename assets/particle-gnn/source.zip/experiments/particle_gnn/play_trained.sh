#!/usr/bin/env bash
# Replay the selected held-out box trajectory with recurrent GNN particle dynamics.
set -euo pipefail
TASK_ROOT=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/../.." && pwd)
exec bash "$TASK_ROOT/experiments/particle_gnn/python.sh" \
  "$TASK_ROOT/experiments/particle_gnn/play.py" \
  --checkpoint "$TASK_ROOT/particle_nerd_plan/results/particle_gnn_full_training/model/best.pt" \
  --episode "$TASK_ROOT/particle_nerd_plan/results/particle_gnn_trained_demo.hdf5" \
  --compile "$@"

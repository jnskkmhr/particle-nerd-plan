"""Train the 50 Hz all-particle GNN, with episode-held-out validation and checkpoints."""

import argparse
import json
import os
from pathlib import Path
import random
import time

import numpy as np
import torch
import torch.distributed as dist
from torch.nn.parallel import DistributedDataParallel

from data import Episodes
from features import Features
from model import ParticleGNN,integrate


@torch.no_grad()
def evaluate(model,episodes,features,samples=24):
    model.eval()
    rng=np.random.default_rng(914)
    errors=[]
    for _ in range(samples):
        s=episodes.sample(rng,device=features.device)
        inputs=features.prepare(s["x"],s["history"],s["pose"],s["body_velocity"],s["material"],s["mass"],compact=True)
        with torch.autocast("cuda",dtype=torch.bfloat16):
            correction=model(*inputs)
        px,pv=integrate(s["x"],s["history"],correction,model.config["dt"])
        near=inputs[3][:,1,0]>.0
        moving=torch.linalg.vector_norm(s["next_v"],dim=-1)>.05
        xerror=(px-s["next_x"]).square().sum(-1)
        verror=(pv-s["next_v"]).square().sum(-1)
        baseline=(s["x"]+.02*s["history"][:,-3:]-s["next_x"]).square().sum(-1)
        errors.append([xerror.mean().item(),verror.mean().item(),baseline.mean().item(),
            xerror[near].mean().item() if near.any() else np.nan,
            xerror[moving].mean().item() if moving.any() else np.nan])
    mean=np.nanmean(errors,axis=0)
    model.train()
    return dict(position_rmse_m=float(np.sqrt(mean[0])),velocity_rmse_m_s=float(np.sqrt(mean[1])),
                constant_velocity_position_rmse_m=float(np.sqrt(mean[2])),
                near_box_position_rmse_m=float(np.sqrt(mean[3])),moving_particle_position_rmse_m=float(np.sqrt(mean[4])),
                transitions=samples)


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument("--data",type=Path,required=True)
    p.add_argument("--output",type=Path,required=True)
    p.add_argument("--steps",type=int,default=10000)
    p.add_argument("--hidden",type=int,default=64)
    p.add_argument("--passes",type=int,default=3)
    p.add_argument("--history",type=int,default=3)
    p.add_argument("--evaluate-every",type=int,default=500)
    p.add_argument("--validation-samples",type=int,default=24)
    p.add_argument("--learning-rate",type=float,default=3e-4)
    p.add_argument("--seed",type=int,default=7103)
    p.add_argument("--resume",type=Path)
    args=p.parse_args()
    rank=int(os.environ.get("RANK",0));world=int(os.environ.get("WORLD_SIZE",1));local=int(os.environ.get("LOCAL_RANK",0))
    torch.cuda.set_device(local)
    device=f"cuda:{local}"
    if world>1:
        dist.init_process_group("nccl")
    torch.manual_seed(args.seed);np.random.seed(args.seed);random.seed(args.seed)
    torch.set_float32_matmul_precision("high")
    rng=np.random.default_rng(args.seed+rank*100003)
    train=Episodes(args.data,"train",args.history)
    validation=Episodes(args.data,"validation",args.history)
    assert not ({r['index'] for r in train.records}&{r['index'] for r in validation.records})
    model=ParticleGNN(hidden=args.hidden,passes=args.passes,history=args.history).to(device)
    optimizer=torch.optim.AdamW(model.parameters(),lr=args.learning_rate,weight_decay=1e-6)
    start_step=0;best=float("inf")
    if args.resume:
        saved=torch.load(args.resume,map_location=device,weights_only=False)
        model.load_state_dict(saved["model"]);optimizer.load_state_dict(saved["optimizer"])
        start_step=saved["step"];best=saved["best"]
    forward=DistributedDataParallel(model,device_ids=[local]) if world>1 else model
    features=Features(16384,history=args.history,device=device)
    args.output.mkdir(parents=True,exist_ok=True)
    run=dict(arguments={k:str(v) if isinstance(v,Path) else v for k,v in vars(args).items()},
        config=model.config,train_episodes=len(train.records),validation_episodes=len(validation.records),world_size=world,
        model_input="current particle position, three velocity states, current box pose/velocity, material parameters, ground geometry",
        model_output="next particle position and endpoint velocity at 50 Hz",
        split="episode hash; test episodes are never used for training or checkpoint selection",
        particle_count=16384,grid_spacing_m=.04)
    if rank==0:
        (args.output/"run.json").write_text(json.dumps(run,indent=2)+"\n")
    start=time.time();losses=[]
    for step in range(start_step+1,args.steps+1):
        s=train.sample(rng,device)
        # Small correlated velocity-history noise; correct towards the clean
        # reference next state, including the noisy baseline displacement.
        history=s["history"]+torch.randn_like(s["history"])*.005
        inputs=features.prepare(s["x"],history,s["pose"],s["body_velocity"],s["material"],s["mass"],compact=True)
        optimizer.zero_grad(set_to_none=True)
        with torch.autocast("cuda",dtype=torch.bfloat16):
            correction=forward(*inputs)
        px,pv=integrate(s["x"],history,correction,.02)
        near=inputs[3][:,1,0].detach()
        moving=(torch.linalg.vector_norm(s["next_v"],dim=-1)>.05).float()
        weight=1.+3.*near+moving
        position=((px-s["next_x"])/.02).square().sum(-1)
        velocity=(pv-s["next_v"]).square().sum(-1)
        # Every particle contributes; emphasize particles affected by the box.
        loss=((position+.5*velocity)*weight).sum()/weight.sum()
        loss.backward()
        torch.nn.utils.clip_grad_norm_(model.parameters(),1.)
        lr=args.learning_rate*(.1+.9*.5*(1+np.cos(np.pi*step/args.steps)))
        for group in optimizer.param_groups:
            group["lr"]=lr
        optimizer.step()
        losses.append(float(loss.detach()))
        if rank==0 and step%25==0:
            print(json.dumps(dict(event="training",step=step,loss=float(np.mean(losses[-25:])),elapsed_s=time.time()-start)),flush=True)
        if step%args.evaluate_every==0 or step==args.steps:
            if world>1:
                dist.barrier()
            if rank==0:
                metrics=evaluate(model,validation,features,args.validation_samples)
                row=dict(step=step,train_loss=float(np.mean(losses[-args.evaluate_every:])),elapsed_s=time.time()-start,**metrics)
                with (args.output/"metrics.jsonl").open("a") as f:f.write(json.dumps(row)+"\n")
                improved=metrics["position_rmse_m"]<best
                best=min(best,metrics["position_rmse_m"])
                checkpoint=dict(model=model.state_dict(),optimizer=optimizer.state_dict(),step=step,best=best,config=model.config,run=run)
                torch.save(checkpoint,args.output/"last.partial.pt")
                os.replace(args.output/"last.partial.pt",args.output/"last.pt")
                if improved:
                    torch.save(checkpoint,args.output/"best.pt")
                (args.output/"progress.json").write_text(json.dumps(row,indent=2)+"\n")
                print(json.dumps(dict(event="validation",**row)),flush=True)
            if world>1:
                dist.barrier()
    if rank==0:
        (args.output/"COMPLETE.json").write_text(json.dumps(dict(steps=args.steps,best_validation_position_rmse_m=best,elapsed_s=time.time()-start),indent=2)+"\n")
    if world>1:dist.destroy_process_group()


if __name__=="__main__":main()

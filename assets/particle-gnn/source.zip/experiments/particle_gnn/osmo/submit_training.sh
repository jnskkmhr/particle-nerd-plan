#!/usr/bin/env bash
set -euo pipefail
script_dir=$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)
dataset_url=${1:?Usage: submit_training.sh DATASET_STORAGE_URL [template overrides]}
shift
export PARTICLE_WORKFLOW="$script_dir/training.yaml"
exec bash "$script_dir/submit.sh" "dataset_url=$dataset_url" "$@"

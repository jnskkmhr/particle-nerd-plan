#!/usr/bin/env bash
set -euo pipefail
script_dir=$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)
export PARTICLE_WORKFLOW="$script_dir/collection.yaml"
exec bash "$script_dir/submit.sh" "$@"

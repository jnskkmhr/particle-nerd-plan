# Particle GNN cloud runtime

The source bundle combines the current `IsaacLab-particle-nerd/source` packages,
its `examples/particle_nerd` modules, and the current experiment scripts. It copies
the **installed** Newton, Warp (including native libraries), and Newton USD schema
distributions from the same environment as the validated local previews. This
avoids fetching a newer branch head or rebuilding a different Warp revision.
Other runtime requirements are pinned to their locally installed versions.

The scene consists of generated particles, one primitive box, and a plane, so
robot meshes and external IsaacLab asset collections are unnecessary. The
snapshot manifest records source file hashes and package provenance. Each task
copies that manifest into its output.

Submit the short environment test:

```bash
bash experiments/particle_gnn/osmo/submit.sh
```

This uses one GPU in `isaac-lab-l40-07`, 8 CPUs, 64 GiB memory and 88 GiB storage.
It waits for a 7.5 kg box to settle and records another 0.2 seconds. This short
test validates the simulation runtime; it does not measure sustained interaction
quality or train a network.

To run a different experiment, pass template overrides to the same launcher:

```bash
bash experiments/particle_gnn/osmo/submit.sh \
  workflow_name=particle-gnn-example \
  'command=python experiments/particle_gnn/preview.py --case continuous-drag --body-mass 7.5 --name preview --output "$PARTICLE_OUTPUT/episodes" --duration 5'
```

Every submission creates a fresh snapshot. Avoid single quotes inside `command`
because the workflow deliberately wraps that trusted command in shell single
quotes. The task starts in the unpacked bundle root with its Python environment
active. `PARTICLE_OUTPUT` is the OSMO output directory.

Storage is separate from G1 training results:

```text
swift://pdx.s8k.io/AUTH_team-isaac-sqa/isaac-sqa/jkamohara/particle-gnn/
  snapshots/<timestamp>-<suffix>/bundle.tar.gz
  snapshots/<timestamp>-<suffix>/bundle.sha256
  runs/<workflow-id>/snapshot.json
  runs/<workflow-id>/episodes/
```

Local staging is retained in `experiments/particle_gnn/cloud-stage/`, including
the CLI submission response. Successful submission is not evidence of successful
simulation; check the returned workflow and its output before launching a full
collection campaign.

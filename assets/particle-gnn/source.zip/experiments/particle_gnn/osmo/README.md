# Particle GNN cloud runtime

The source bundle combines the current `IsaacLab-particle-nerd/source` packages,
its `examples/particle_nerd` modules, and the current experiment scripts. It copies
the **installed** Newton, Warp (including native libraries), and Newton USD schema
distributions from the same environment as the validated local previews. This
avoids fetching a newer branch head or rebuilding a different Warp revision.
Other runtime requirements are pinned to their locally installed versions.

The scene consists of generated particles, one primitive box, and a plane.
IsaacLab's `GroundPlaneCfg` downloads its standard checker-plane USD through the
pinned `omniverseclient` package. Robot meshes and large asset collections are
unnecessary. The small `apps` launcher configuration is bundled because core
asset discovery reads it even without Kit. The
snapshot manifest records source file hashes and package provenance. Each task
copies that manifest into its output.

Submit the short environment test:

```bash
bash experiments/particle_gnn/osmo/submit.sh
```

This uses one GPU in `isaac-lab-l40-07`, 8 CPUs, 64 GiB memory and 88 GiB storage.
It waits for a 7.5 kg box to settle and records another 0.2 seconds. This short
test validates the simulation runtime; it does not measure sustained interaction
quality or train a network.

To run a different experiment, pass template overrides to the same launcher:

```bash
bash experiments/particle_gnn/osmo/submit.sh \
  workflow_name=particle-gnn-example \
  'command=python experiments/particle_gnn/preview.py --case continuous-drag --body-mass 7.5 --name preview --output "$PARTICLE_OUTPUT/episodes" --duration 5'
```

Every submission creates a fresh snapshot. Avoid single quotes inside `command`
because the workflow deliberately wraps that trusted command in shell single
quotes. The task starts in the unpacked bundle root with its Python environment
active. `PARTICLE_OUTPUT` is the OSMO output directory.

Storage is separate from G1 training results:

```text
swift://pdx.s8k.io/AUTH_team-isaac-sqa/isaac-sqa/jkamohara/particle-gnn/
  snapshots/<timestamp>-<suffix>/bundle.tar.gz
  snapshots/<timestamp>-<suffix>/bundle.sha256
  runs/<workflow-id>/snapshot.json
  runs/<workflow-id>/episodes/
```

Local staging is retained in `experiments/particle_gnn/cloud-stage/`, including
the CLI submission response. Successful submission is not evidence of successful
simulation; check the returned workflow and its output before launching a full
collection campaign.

## Collection and training templates

The collection template defines 32 independent tasks under `tasks`, each with one
GPU. Task `rank` records episode indices `rank, rank+32, ...` from the same
deterministic 1,000-episode specification. It does not use a group lead that could
terminate sibling tasks. Each task saves its own `shard-<rank>/episodes` directory.
Every five minutes, OSMO uploads only progress JSON and completed-episode campaign
JSON. HDF5 trajectories upload with the final task output; the progress checkpoint
alone is not a recoverable dataset backup.

After the simulation smoke test and local pilot pass, submit collection:

```bash
bash experiments/particle_gnn/osmo/submit_collection.sh
```

For a smaller explicitly requested pilot, numeric overrides belong to `--set`:

```bash
bash experiments/particle_gnn/osmo/submit_collection.sh \
  workflow_name=particle-gnn-collect-pilot --set num_shards=2 num_episodes=10
```

Once every collection shard is complete, the training launcher snapshots the
latest model code and mounts the entire collection output prefix as `input:1`:

```bash
bash experiments/particle_gnn/osmo/submit_training.sh \
  swift://pdx.s8k.io/AUTH_team-isaac-sqa/isaac-sqa/jkamohara/particle-gnn/runs/COLLECTION_WORKFLOW_ID/
```

Training runs `torchrun --standalone --nproc_per_node=4` on one node, with 16 CPUs,
128 GiB RAM and 250 GiB storage, for 10,000 optimizer steps. It first runs the GPU
feature/integration checks, then evaluates the best checkpoint on 12 held-out
episodes with 250-step rollouts. It checkpoints model weights and metric files
every five minutes. Complete bootstrap and task stdout/stderr are preserved in
`runtime.log` in the output directory. Collection defaults to 8 CPUs,
64 GiB RAM and 88 GiB storage per task. Both templates accept `source_url` and
`output_url` overrides; training also accepts `dataset_url` and `num_steps`.

These templates are preparation, not proof of a successful campaign. The current
task status and final artifact validation must determine completion.

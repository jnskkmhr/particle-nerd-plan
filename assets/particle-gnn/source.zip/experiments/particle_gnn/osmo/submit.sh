#!/usr/bin/env bash
# Snapshot current approved code before every submission; do not upload old code.
set -euo pipefail
project_root=$(cd "$(dirname "${BASH_SOURCE[0]}")/../../.." && pwd)
cd "$project_root"
snapshot_name=$(date -u +%Y%m%dT%H%M%SZ)-$RANDOM
stage="experiments/particle_gnn/cloud-stage/$snapshot_name"
bash experiments/particle_gnn/python.sh experiments/particle_gnn/osmo/stage.py --output "$stage"
storage_root=swift://pdx.s8k.io/AUTH_team-isaac-sqa/isaac-sqa/jkamohara/particle-gnn
source_url="$storage_root/snapshots/$snapshot_name"
osmo data upload "$source_url/" "$stage/bundle.tar.gz" "$stage/bundle.sha256"
osmo workflow submit "${PARTICLE_WORKFLOW:-experiments/particle_gnn/osmo/workflow.yaml}" \
    --pool isaac-lab-l40-07 --format-type json \
    --set-string "source_url=$source_url/" "$@" | tee "$stage/submission.json"

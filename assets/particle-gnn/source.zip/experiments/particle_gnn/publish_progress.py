"""Update the existing HTML page from an explicit, locally verified status record."""

import argparse
import html
import json
from pathlib import Path
import re
import zipfile


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("status", type=Path)
    args = p.parse_args()
    root = Path(__file__).resolve().parents[2]
    site = root / "particle_nerd_plan"
    status = json.loads(args.status.read_text())
    esc = html.escape
    rows = "".join(
        f"<tr><td>{esc(item['stage'])}</td><td>{esc(item['status'])}</td><td>{esc(item['detail'])}</td></tr>"
        for item in status["stages"]
    )
    updates = "".join(f"<li>{esc(item)}</li>" for item in status.get("notes", []))
    links = " · ".join(
        f'<a href="{esc(item["url"], quote=True)}">{esc(item["label"])}</a>'
        for item in status.get("links", [])
    )
    fragment = f"""<section id="campaign-status"><h2>Dataset collection, training and inference</h2>
<p class="small">Updated {esc(status["updated_utc"])}. Results below distinguish completed checks from planned work.</p>
<table><tr><th>Stage</th><th>Status</th><th>Evidence / next action</th></tr>{rows}</table>
<p><b>Dataset target:</b> 1,000 independent episodes: 776 training, 109 validation and 115 test episodes, split by an episode-ID hash. Each episode contains five seconds after settling, sampled at 50 Hz, plus its initial settling interval. Box mass is sampled uniformly from 5–10 kg. Motion mix: 20% undisturbed, 40% sustained pushing, 40% continuous dragging. Force strength, direction, duration, drag path, initial box state and particle jitter vary between episodes.</p>
<p><b>Fixed conditions:</b> sand material specified below; initial sand volume 1 × 1 × 0.5 m; MPM grid 0.04 m; 16,384 particles; box 0.12 × 0.12 × 0.08 m; rigid ground with no retaining walls. This experiment does not establish generalization across material parameters, particle spacing or object geometry.</p>
<p><b>GNN:</b> three message-passing layers, 64 latent features, 0.07 m neighbor radius. Inputs are current particle positions, three particle velocity states, material parameters, and current box pose/velocity. Ground and box use shared distance, normal, surface-velocity, inverse-mass and friction features; direct body influence is limited by distance. All particles are updated. Separate heads predict next position and endpoint velocity at 50 Hz. No reference stress, deformation state or future box state enters inference.</p>
<details><summary>Implementation: input, computation and output of one particle step</summary>
<table><tr><th>Operation</th><th>Inputs</th><th>Outputs</th></tr>
<tr><td>1. Construct particle neighborhoods — Warp</td><td>Current particle positions</td><td>Directed edges between all pairs within 0.07 m; relative position, distance and velocity</td></tr>
<tr><td>2. Encode particle and rigid geometry — Warp + Torch</td><td>Three particle velocity states, material values, current ground/box geometry and box velocity</td><td>64 features per particle and edge; a shared rigid-surface encoder contributes only within the interaction radius</td></tr>
<tr><td>3. Exchange particle messages — Torch</td><td>Features at neighboring particles and their connecting edges</td><td>Updated particle features after three message-passing layers</td></tr>
<tr><td>4. Predict and advance — Torch + Warp</td><td>Updated particle features and current particle state</td><td>Next position, endpoint velocity and shifted velocity history for every particle</td></tr></table>
<p><code>position_next = position + 0.02 × (velocity + displacement_rate_correction)</code><br><code>velocity_next = velocity + endpoint_velocity_correction</code></p>
<p>The network predicts both corrections. They are separate because average motion during a 20 ms interval differs from velocity at the interval endpoint. During training, the next MPM state is a target for the loss; it is not a model input. During recurrent inference, predicted particle states become the next inputs.</p>
<p>Material inputs: density, Young’s modulus, Poisson ratio, friction, yield pressure, tensile yield ratio, yield stress, hardening, dilatancy and viscosity. Particle mass, particle radius and time step are also supplied. These material values are fixed in the present dataset, so their presence as inputs does not establish material generalization.</p>
</details>
<p><b>Evaluation:</b> compare held-out next-step position and velocity with a constant-velocity baseline; separately measure five-second recurrent particle rollouts. Initial rollout tests replay reference box motion to isolate particle prediction. They do not establish closed-loop force-estimation or box-motion accuracy. Inference uses Warp for GPU geometry/neighborhood/state updates and Torch for the network. CUDA graph capture is not enabled in this new implementation yet.</p>
<p class="small">Episode 2 was inspected during implementation checks and is excluded from final accuracy reporting, leaving 114 eligible test episodes. Training-setting comparisons use validation episodes.</p>
<ul>{updates}</ul><p>{links}</p><p><a href="assets/particle-gnn/campaign-status.json">Status record</a> · <a href="assets/particle-gnn/source.zip">Reproduction code and run instructions</a></p></section>"""
    path = site / "particle_gnn_development.html"
    page = path.read_text()
    if '<section id="campaign-status">' in page:
        page = re.sub(
            r'<section id="campaign-status">.*?</section>',
            lambda _: fragment,
            page,
            count=1,
            flags=re.S,
        )
    else:
        page = page.replace(
            "<h2>Reference simulation and recording</h2>",
            fragment + "<h2>Reference simulation and recording</h2>",
        )
    page = page.replace(
        "<b>Stage: review the MPM examples before dataset collection.</b>",
        "<b>Stage: collection and GNN training authorized.</b>",
    )
    page = page.replace(
        "The 1,000-trajectory OSMO campaign and model training have not started.",
        "Current collection, training and validation status is recorded below.",
    )
    page = page.replace(
        "No large collection or training job will start before review.",
        "The examples were reviewed; collection and training are now authorized. See current status above.",
    )
    path.write_text(page)
    (site / "assets/particle-gnn/campaign-status.json").write_text(
        json.dumps(status, indent=2) + "\n"
    )
    with zipfile.ZipFile(
        site / "assets/particle-gnn/source.zip", "w", compression=zipfile.ZIP_DEFLATED
    ) as z:
        for pattern in (
            "README.md",
            "*.py",
            "*.sh",
            "osmo/*.py",
            "osmo/*.sh",
            "osmo/*.yaml",
            "osmo/README.md",
        ):
            for source in sorted((root / "experiments/particle_gnn").glob(pattern)):
                z.write(source, source.relative_to(root))
    print("Updated HTML campaign status and source archive")


if __name__ == "__main__":
    main()

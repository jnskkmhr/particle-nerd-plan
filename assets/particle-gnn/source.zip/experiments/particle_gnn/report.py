"""Generate the preview page, measured force plots, and dataset specification."""

import json
from pathlib import Path

import h5py
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

ROOT=Path(__file__).resolve().parents[2]
SITE=ROOT/"particle_nerd_plan"
DATA=SITE/"results/particle_gnn_preview_v1"
ASSETS=SITE/"assets/particle-gnn"
ASSETS.mkdir(parents=True,exist_ok=True)
CASES={"rest":"Undisturbed settling", "push-spin":"Horizontal pushes and rotation", "drag-lift":"Off-center dragging and lift"}
sections=[]
results=[]
for case,title in CASES.items():
    path=DATA/f"{case}.json"
    if not path.exists():
        sections.append(f'<section><h2>{title}</h2><p>Sample pending. No result is reported yet.</p></section>')
        continue
    m=json.loads(path.read_text())
    with h5py.File(DATA/f"{case}.hdf5","r") as f:
        t=f["time_s"][:]
        q=f["body_pose"][:]
        v=f["body_velocity"][:]
        applied=f["applied_feedback_wrench"][:]
        current=f["material_on_body_wrench"][:]
        external=f["external_wrench"][:]
        # Wrench sampled before step k is applied during transition k -> k+1.
        force_time=t[:-1]
        residual=1.5*np.diff(v[:,:3],axis=0)/m["dt"]-applied[:,:3]-external[:,:3]-np.array([0,0,-1.5*9.81])
        metrics=dict(case=case,settled_time_s=m["settled_time_s"],duration_s=float(t[-1]),
            max_post_settlement_box_center_displacement_m=float(np.linalg.norm(q[m["settled_step"]:,:3]-q[m["settled_step"],:3],axis=1).max()),
            max_material_force_N=float(np.linalg.norm(current[:,:3],axis=1).max()),
            mean_body_force_balance_residual_N=float(np.linalg.norm(residual,axis=1).mean()),
            max_body_force_balance_residual_N=float(np.linalg.norm(residual,axis=1).max()),
            ground_violation_fraction=m["max_fraction_particle_centers_below_ground_by_more_than_grid"])
        fig,axs=plt.subplots(3,1,figsize=(10,8),sharex=True,layout="constrained")
        for k,label in enumerate(("Fx","Fy","Fz")):
            axs[0].plot(force_time,current[:,k],label=label,lw=1)
            axs[1].plot(force_time,external[:,k],label=label,lw=1)
        axs[0].set_ylabel("Sand on box [N]")
        axs[1].set_ylabel("External force [N]")
        axs[2].plot(t,q[:,0],label="Box center x")
        axs[2].plot(t,q[:,1],label="Box center y")
        axs[2].plot(t,q[:,2],label="Box center z")
        axs[2].set_ylabel("Position [m]")
        axs[2].set_xlabel("Time since initial release [s]")
        for ax in axs:
            ax.axvline(m["settled_time_s"],color="black",ls="--",lw=1)
            ax.legend(ncol=3,loc="upper right",fontsize=8)
            ax.grid(alpha=.2)
        fig.suptitle(title+" — dashed line: settled box, start of five-second window")
        fig.savefig(ASSETS/f"{case}-forces.svg")
        svg=ASSETS/f"{case}-forces.svg"
        svg.write_text("\n".join(line.rstrip() for line in svg.read_text().splitlines())+"\n")
        plt.close(fig)
        np.savetxt(ASSETS/f"{case}-forces.csv",np.column_stack((force_time,current,applied,external)),delimiter=",",
            header="time_s,"+",".join(f"{prefix}_{component}" for prefix in ("current_sand","applied_sand","external") for component in ("Fx_N","Fy_N","Fz_N","Tx_Nm","Ty_Nm","Tz_Nm")),comments="")
    results.append(dict(manifest=m,measurements=metrics))
    (ASSETS/f"{case}.json").write_text(json.dumps(results[-1],indent=2)+"\n")
    media=(f'<video controls playsinline preload="metadata" poster="assets/particle-gnn/{case}-poster.jpg"><source src="assets/particle-gnn/{case}.mp4" type="video/mp4"></video>'
           if (ASSETS/f"{case}.mp4").exists() else '<p>Simulation complete; video rendering pending.</p>')
    description={"rest":"No external forces after release. This control records spontaneous spreading and residual motion after the box settles.",
      "push-spin":"Three smooth force and torque pulses, with seed-randomized times and directions. The box remains freely dynamic.",
      "drag-lift":"A moving spring target pulls an off-center point on the box. The force is capped at 45 N; its torque is computed about the box center. Box motion is not prescribed."}[case]
    sections.append(f'''<section id="{case}"><h2>{title}</h2><p>{description}</p>{media}
<p>Box settling criterion reached at <b>{m['settled_time_s']:.2f} s</b>; then five seconds recorded. All particle and box states remained finite. Maximum fraction of particle centers more than 0.04 m below the rigid ground: <b>{100*metrics['ground_violation_fraction']:.3f}%</b>.</p>
<p>Maximum box-center displacement after settlement: <b>{100*metrics['max_post_settlement_box_center_displacement_m']:.1f} cm</b>. Maximum translational force-balance residual: <b>{metrics['max_body_force_balance_residual_N']:.2g} N</b>, using the recorded applied sand force, gravity, and external force.</p>
<img src="assets/particle-gnn/{case}-forces.svg" alt="Sand force on the box, applied external force, and box center position versus time">
<p class="small">Forces are world-axis components. Sand-on-box force excludes gravity and external disturbances. The coupled rigid solver applies the previous step’s sand force. Position z is measured above the rigid ground at z = 0; the initial sand surface is z = 0.5 m. Video is real time at 25 fps, selecting every second 50 Hz particle frame. Particle display radius is 0.012 m; this does not change simulation sampling.</p>
<p><a href="assets/particle-gnn/{case}.json">Exact settings and measurements</a> · <a href="assets/particle-gnn/{case}-forces.csv">200 Hz forces</a></p></section>''')

page='''<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>Particle GNN development</title>
<style>body{max-width:1080px;margin:36px auto;padding:0 22px;font:18px/1.6 system-ui;color:#24383d;background:#f7f9f7}h1{font-size:38px;line-height:1.2}h2{font-size:27px;margin-top:35px}a{color:#386481}table{border-collapse:collapse;width:100%;font-size:16px}td,th{padding:10px;text-align:left;border-bottom:1px solid #cbd7d8}th{background:#eaf0ee}.note{padding:18px;border-left:4px solid #287e75;background:#edf3f0}.small{font-size:15px;color:#566970}img,video{width:100%;display:block}video{background:#24383d}.scroll{overflow-x:auto}nav{font-size:16px;margin-bottom:25px}code{overflow-wrap:anywhere}</style></head><body>
<nav><a href="index.html">Methodology</a> · <a href="gnn-implementation.html">Previous GNN</a> · <a href="g1_force_estimation.html">G1 force estimation</a></nav>
<h1>Particle GNN development</h1>
<p class="note"><b>Stage: review the MPM examples before dataset collection.</b> These videos use MPM particle dynamics and MuJoCo Warp rigid-body dynamics. No GNN or analytical force estimator drives these examples. The 1,000-trajectory OSMO campaign and model training have not started.</p>
<h2>Reference simulation and recording</h2>
<table><tr><th>Setting</th><th>Value</th></tr>
<tr><td>Scene</td><td>Rigid ground, sand particles, and one dynamic box. No retaining walls or tray.</td></tr>
<tr><td>Initial sand volume</td><td>1.0 × 1.0 × 0.5 m. Ground z = 0; initial sand surface z = 0.5 m. The unsupported pile can spread.</td></tr>
<tr><td>MPM grid / particle sampling</td><td>0.04 m grid; 32 × 32 × 16 = 16,384 particles; 0.03125 m initial spacing; independent jitter up to 20% of spacing.</td></tr>
<tr><td>Integration / solver</td><td>200 Hz coupled physics; APIC transfer; sparse MPM grid; maximum 25 solver iterations, tolerance 10⁻⁴. Standard Newton convergence loop; this is not a claim of converged ground truth.</td></tr>
<tr><td>Particle recording</td><td>50 Hz. Five seconds after the box settles, giving 251 states. These previews also retain the preceding settling interval.</td></tr>
<tr><td>Box</td><td>0.12 × 0.12 × 0.08 m; 1.5 kg; rigid-surface friction 0.6. Random initial position, orientation, linear velocity and angular velocity.</td></tr>
<tr><td>Sand material</td><td>Density 1,600 kg/m³; Young’s modulus 10¹⁵ Pa; Poisson ratio 0.3; friction 0.48; yield pressure 10¹⁵ Pa. Tensile yield ratio, yield stress, hardening, dilatancy and viscosity are zero.</td></tr>
<tr><td>Settling criterion</td><td>Box speed &lt; 0.02 m/s and angular speed &lt; 0.2 rad/s for 0.3 s, with sand support force &gt; 1.5 N, after at least 0.5 s. This tests the box, not equilibrium of every sand particle. Failure to settle within 5 s stops the sample.</td></tr>
</table>
<p>Initial box-center x/y offsets are within ±0.08 m; center height is 0.60–0.66 m above ground. Roll and pitch are within ±0.25 rad; yaw within ±3.14 rad. Initial horizontal velocity is within ±0.25 m/s, vertical velocity −0.15–0 m/s, roll/pitch angular velocity ±1 rad/s, and yaw angular velocity ±2 rad/s. Each preview has a different seed; these are illustrative cases, not a controlled accuracy comparison.</p>
<h2>MPM motion examples</h2>
<p><a href="#rest">Undisturbed settling</a> · <a href="#push-spin">Pushes and rotation</a> · <a href="#drag-lift">Dragging and lift</a></p>
'''+"\n".join(sections)+'''
<h2>GNN design to test</h2>
<p><a href="assets/particle-gnn/validation.json">Independent recording checks</a> verify finite data, 50 Hz particle timestamps, 251 post-settlement states, the settling criterion, one-step force-feedback alignment, translational force balance, and reconstruction of every applied disturbance from its recorded parameters.</p>
<p>Predict particle position and velocity every 20 ms from motion history, neighboring particles, material parameters, rigid geometry and rigid-surface velocity. No reference stress or deformation state is required at inference. Keep grid spacing and particle sampling fixed for this first experiment; approximately 0.07 m is the proposed graph radius at this sampling.</p>
<p>Compare the existing model with a model that limits the intruder’s direct effect to possible contact and propagates disturbance through particle neighbors. Continue to model gravity, settling and relaxation after contact ends. A blanket rule that freezes every particle not touching the box would suppress valid motion. Include undisturbed controls and measure accumulated drift. All particles remain represented; no region selector is required.</p>
<p>Evaluate 50 Hz learned motion both directly and after interpolation to the 200 Hz rigid-body/force-estimation interval. Interpolation cannot recover unresolved impact peaks. Retain a small high-frequency validation subset to quantify lost contact information. No interpolation accuracy has been established yet.</p>
<h2>Dataset, OSMO training, and local inference</h2>
<ol><li><b>Review these examples.</b> Check the terrain, box size, settling, disturbance strength, and force profiles before committing to a collection campaign.</li>
<li><b>Collect 1,000 five-second trajectories.</b> Use independent seeds and randomized disturbances after settling. Reserve full episodes for validation and testing. Start with sand; material diversity needs additional parameter coverage and inputs.</li>
<li><b>Store bounded-size files in object storage.</b> Float32 particle position plus velocity requires 98.7 GB for 1,000 × 251 states, before compression. Constants are stored once per episode. Settling recordings and a high-frequency validation subset add storage.</li>
<li><b>Run collection and training through OSMO.</b> Reuse the IsaacLab code-snapshot and output/checkpoint workflow. Measure environments per GPU before selecting batch size; 100 simultaneous environments is not yet verified. Stream recording to disk instead of retaining complete trajectories on GPU. GNN distributed training needs its own data loader and gradient synchronization.</li>
<li><b>Download the selected checkpoint for local inference.</b> Evaluate the GNN with analytical body-force reconstruction and MJWarp, without MPM. Report particle drift, ground penetration, force error, box-motion error and full-step latency.</li></ol>
<p class="small">The previous selected GNN used only 48 training episodes of 1.5 s. The later 36-episode diversity pilot did not consistently improve coupled forces and box motion. These new previews are reference-data checks, not evidence of improved learned prediction. No large collection or training job will start before review.</p>
<p><a href="assets/particle-gnn/source.zip">Download preview, rendering and validation scripts</a>. The launcher uses the existing IsaacLab particle-NeRD worktree and local Newton runtime. Run <code>bash experiments/particle_gnn/python.sh experiments/particle_gnn/preview.py --case push-spin --output /tmp/particle-gnn-sample</code> from the particle_nerd directory. Completed outputs are never overwritten.</p>
</body></html>'''
(SITE/"particle_gnn_development.html").write_text(page)
(ASSETS/"preview-summary.json").write_text(json.dumps(results,indent=2)+"\n")
print(f"Wrote page: {len(results)}/3 simulations complete")

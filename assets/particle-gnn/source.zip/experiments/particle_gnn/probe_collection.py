"""Read collector progress through OSMO exec when storage checkpoints lag.

Only metadata is read. Failed probes retain the last observed lower bound.
"""

import argparse
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timezone
import errno
import json
import os
from pathlib import Path
import pty
import select
import shlex
import subprocess
import time


def probe(
    workflow, task, path="/osmo/data/output/episodes/progress.json", jsonlines=False
):
    expression = (
        f"[json.loads(line) for line in open({path!r}) if line.strip()]"
        if jsonlines
        else f"json.load(open({path!r}))"
    )
    code = f'import json; d={expression}; print("PROGRESS_JSON="+json.dumps(d))'
    entry = "/tmp/particle-gnn-venv/bin/python -c " + shlex.quote(code)
    master, slave = pty.openpty()
    process = subprocess.Popen(
        [
            "timeout",
            "35s",
            "osmo",
            "workflow",
            "exec",
            workflow,
            task,
            "--connect-timeout",
            "10",
            "--entry",
            entry,
        ],
        stdin=slave,
        stdout=slave,
        stderr=slave,
    )
    os.close(slave)
    chunks = []
    started = time.monotonic()
    try:
        while time.monotonic() - started < 40:
            if select.select([master], [], [], 0.5)[0]:
                try:
                    data = os.read(master, 65536)
                except OSError as error:
                    if error.errno == errno.EIO:
                        break
                    raise
                if not data:
                    break
                chunks.append(data)
            elif process.poll() is not None:
                break
    finally:
        if process.poll() is None:
            process.terminate()
        process.wait(timeout=5)
        os.close(master)
    output = b"".join(chunks).decode(errors="replace")
    marker = "PROGRESS_JSON="
    for line in output.splitlines():
        if marker in line:
            return json.JSONDecoder().raw_decode(line.split(marker, 1)[1])[0]
    return None


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--workflow", required=True)
    parser.add_argument("--cache", type=Path, required=True)
    args = parser.parse_args()
    metadata = json.loads((args.cache / "workflow.json").read_text())
    tasks = [
        t["name"]
        for g in metadata["groups"]
        for t in g["tasks"]
        if t["status"] == "RUNNING"
    ]
    with ThreadPoolExecutor(max_workers=4) as pool:
        for task, progress in zip(
            tasks, pool.map(lambda t: probe(args.workflow, t), tasks)
        ):
            if progress is None:
                continue
            progress["observed_utc"] = datetime.now(timezone.utc).isoformat()
            path = args.cache / "live" / task / "progress.json"
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_text(json.dumps(progress, indent=2) + "\n")
            print(
                json.dumps(dict(task=task, completed=progress["completed"])), flush=True
            )


if __name__ == "__main__":
    main()

"""Compare block mass at matched initial conditions and elapsed simulation time."""

import itertools
import json
from pathlib import Path

import h5py
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
from scipy.spatial.transform import Rotation

ROOT=Path(__file__).resolve().parents[2]
SITE=ROOT/"particle_nerd_plan"
DATA=SITE/"results/particle_gnn_preview_v1"
ASSETS=SITE/"assets/particle-gnn"
names=("rest","rest-5kg","rest-10kg")
results=[]
fig,axs=plt.subplots(2,1,figsize=(10,7),sharex=True,layout="constrained")
initial=None
baseline=None
reference_config=None
for name in names:
    m=json.loads((DATA/f"{name}.json").read_text())
    config={k:m[k] for k in ("scene","material","body_size_m","seed","dt","record_hz","solver_max_iterations","solver_tolerance")}
    if reference_config is None:
        reference_config=config
    else:
        assert config==reference_config,(name,"changed simulation configuration")
    with h5py.File(DATA/f"{name}.hdf5","r") as f:
        for key in f:
            for start in range(0,len(f[key]),16):
                assert np.isfinite(f[key][start:start+16]).all(),(name,key)
        init=[f[k][0] for k in ("particle_position","particle_velocity","body_pose","body_velocity")]
        if initial is None:
            initial=init
        else:
            for a,b in zip(initial,init,strict=True):
                np.testing.assert_array_equal(a,b)
        assert np.all(f["external_wrench"][:]==0),name
        assert m["scene"]["voxel_size_m"]==.04
        assert not m["scene"]["container_walls"]
        t=f["time_s"][:]
        q=f["body_pose"][:]
        v=f["body_velocity"][:]
        mass=m["body_mass_kg"]
        applied=f["applied_feedback_wrench"][:]
        current=f["material_on_body_wrench"][:]
        residual=mass*np.diff(v[:,:3],axis=0)/m["dt"]-applied[:,:3]-[0,0,-mass*9.81]
        residual_max=float(np.linalg.norm(residual,axis=1).max())
        assert residual_max<.01,(name,residual_max)
        np.testing.assert_allclose(applied[1:],current[:-1],atol=.003,rtol=1e-4)
        step=round(5./m["dt"])
        frame=int(np.flatnonzero(f["frame_steps"][:]==step)[0])
        x=f["particle_position"][frame]
        corners=np.array(list(itertools.product(*[(-s/2,s/2) for s in m["body_size_m"]])))
        corner_world=Rotation.from_quat(q[step,3:]).apply(corners)+q[step,:3]
        lowest=float(corner_world[:,2].min())
        distance=np.linalg.norm(x[:,:2]-q[step,:2],axis=1)
        ring=(distance>=.12)&(distance<=.20)
        assert ring.sum()>20
        surface=float(np.quantile(x[ring,2],.95))
        if baseline is None:
            baseline=x.copy()
            # Same initial particle IDs define the neighborhood in every case.
            near=np.linalg.norm(initial[0][:,:2]-initial[2][:2],axis=1)<.25
        rms=float(np.sqrt(np.mean(np.sum((x[near]-baseline[near])**2,axis=1))))
        result=dict(name=name,mass_kg=mass,comparison_time_s=5.,settled_time_s=m["settled_time_s"],
            box_center_z_m=float(q[step,2]),lowest_box_corner_z_m=lowest,
            nearby_surface_estimate_z_m=surface,approximate_embedment_m=max(0.,surface-lowest),
            near_particle_rms_difference_vs_1_5kg_m=rms,near_particle_count=int(near.sum()),
            mean_last_half_second_sand_vertical_force_N=float(current[step-100:step,2].mean()),
            max_force_balance_residual_N=residual_max,
            max_fraction_below_ground_by_more_than_grid=m["max_fraction_particle_centers_below_ground_by_more_than_grid"],
            matched_initial_states=True,all_finite=True)
        results.append(result)
        mask=t<=5.
        axs[0].plot(t[mask],q[mask,2],label=f"{mass:g} kg")
        axs[1].plot(t[:-1][mask[:-1]],current[mask[:-1],2],label=f"{mass:g} kg",lw=1)
        (ASSETS/f"{name}-mass.json").write_text(json.dumps(dict(manifest=m,measurements=result),indent=2)+"\n")
axs[0].set_ylabel("Box center above rigid ground [m]")
axs[1].set_ylabel("Sand-on-box vertical force [N]")
axs[1].set_xlabel("Time since identical initial release [s]")
for ax in axs:
    ax.legend();ax.grid(alpha=.2)
fig.savefig(ASSETS/"mass-comparison.svg")
plt.close(fig)
svg=ASSETS/"mass-comparison.svg"
svg.write_text("\n".join(line.rstrip() for line in svg.read_text().splitlines())+"\n")
(ASSETS/"mass-comparison.json").write_text(json.dumps(results,indent=2)+"\n")
rows="".join(f"<tr><td>{r['mass_kg']:g} kg</td><td>{100*r['box_center_z_m']:.1f} cm</td><td>{100*r['lowest_box_corner_z_m']:.1f} cm</td><td>{100*r['approximate_embedment_m']:.1f} cm</td><td>{1000*r['near_particle_rms_difference_vs_1_5kg_m']:.1f} mm</td></tr>" for r in results)
videos="".join(f'''<div><h3>{mass:g} kg block</h3><video controls playsinline preload="metadata" poster="assets/particle-gnn/{name}-poster.jpg"><source src="assets/particle-gnn/{name}.mp4" type="video/mp4"></video></div>''' for name,mass in (("rest-5kg",5),("rest-10kg",10)))
fragment=f'''<section id="block-mass"><h2>Heavier blocks: 1.5, 5 and 10 kg</h2>
<p>Only block mass changes. Box dimensions remain 0.12 × 0.12 × 0.08 m. Sand, grid spacing, random seed, initial particles, box pose and velocity are identical; exact initial-state equality was checked. These passive drop-and-settle cases isolate mass: no external push or drag is applied.</p>
<video controls playsinline preload="metadata" poster="assets/particle-gnn/mass-comparison-poster.jpg"><source src="assets/particle-gnn/mass-comparison.mp4" type="video/mp4"></video>
<p>Left to right: 1.5 kg, 5 kg, 10 kg. Synchronized by time since release; playback ends at the shortest recording. Individual heavier-block videos below include the complete five-second interval after each box meets the settling criterion.</p>
<p><b>Measured effect:</b> at 5 s, the 5 kg box center is {(results[0]['box_center_z_m']-results[1]['box_center_z_m'])*100:.1f} cm lower than the 1.5 kg box center; the 10 kg box center is {(results[0]['box_center_z_m']-results[2]['box_center_z_m'])*100:.1f} cm lower. The 10 kg case produces the larger nearby particle displacement difference. Approximate embedment is not monotonic between 1.5 and 5 kg because box tilt and the local surface estimate also change; do not interpret this single geometric number as a general mass–penetration law.</p>
<div class="scroll"><table><tr><th>Block mass</th><th>Center height</th><th>Lowest corner height</th><th>Approximate embedment</th><th>Nearby particle RMS difference vs 1.5 kg</th></tr>{rows}</table></div>
<p class="small">All measurements are at t = 5 s after release. Heights are above the rigid ground at z = 0. Approximate embedment is the nearby particle-surface estimate minus the lowest box-corner height, clipped at zero. The surface estimate is the 95th percentile of particle-center heights in a 0.12–0.20 m horizontal annulus around the current box center. This is a coarse geometric indicator, not an exact contact-surface measurement. Particle RMS uses the same particle IDs initially within 0.25 m horizontally of the initial box center; it measures displacement differences caused by changing mass, not prediction error.</p>
<img src="assets/particle-gnn/mass-comparison.svg" alt="Box center height and sand-on-box vertical force for three block masses">
<p>All runs remained finite. Maximum body force-balance residual across the three runs: {max(r['max_force_balance_residual_N'] for r in results):.2g} N. Maximum fraction of particle centers more than one 0.04 m grid cell below ground: {100*max(r['max_fraction_below_ground_by_more_than_grid'] for r in results):.3f}%.</p>
{videos}<p><a href="assets/particle-gnn/mass-comparison.json">Measured mass comparison</a> · <a href="assets/particle-gnn/rest-5kg-mass.json">5 kg settings</a> · <a href="assets/particle-gnn/rest-10kg-mass.json">10 kg settings</a></p></section>'''
(DATA/"mass-section.html").write_text(fragment)
print(json.dumps(results,indent=2))

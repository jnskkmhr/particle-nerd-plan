"""Monitor OSMO collection, checkpoint its observed state and publish HTML progress.

This watcher does not submit training, retry simulations, or change resources.
It exits when collection reaches a terminal state so the caller can audit data.
"""

import argparse
from collections import Counter
from datetime import datetime, timezone
import json
from pathlib import Path
import subprocess
import sys
import time


def run(command, timeout=90):
    return subprocess.run(
        command,
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        timeout=timeout,
    )


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--workflow", required=True)
    p.add_argument("--storage", required=True)
    p.add_argument("--interval", type=int, default=60)
    args = p.parse_args()
    root = Path(__file__).resolve().parents[2]
    site = root / "particle_nerd_plan"
    cache = site / "results/particle_gnn_campaign_cloud_metadata"
    cache.mkdir(parents=True, exist_ok=True)
    status_file = root / "experiments/particle_gnn/status.json"
    previous = None
    last_download = 0
    last_publish = 0
    while True:
        query = run(
            ["osmo", "workflow", "query", args.workflow, "--format-type", "json"]
        )
        if query.returncode:
            print(
                json.dumps(dict(event="query_error", detail=query.stdout[-500:])),
                flush=True,
            )
            time.sleep(args.interval)
            continue
        m = json.loads(query.stdout)
        (cache / "workflow.json").write_text(json.dumps(m, indent=2) + "\n")
        tasks = [t for g in m.get("groups", []) for t in g["tasks"]]
        states = dict(Counter(t["status"] for t in tasks))
        terminal = m["status"] not in ("RUNNING", "PENDING", "WAITING")
        if time.time() - last_download > 120 or terminal:
            transfer = run(
                [
                    "osmo",
                    "data",
                    "download",
                    args.storage,
                    str(cache),
                    "--regex",
                    r".*progress.json$",
                ],
                timeout=180,
            )
            if transfer.returncode:
                print(
                    json.dumps(
                        dict(
                            event="progress_download_error",
                            detail=transfer.stdout[-500:],
                        )
                    ),
                    flush=True,
                )
            last_download = time.time()
        episodes = {}
        for path in cache.rglob("progress.json"):
            for record in json.loads(path.read_text())["episodes"]:
                if record["index"] in episodes:
                    raise ValueError("Duplicate checkpointed episode ID")
                episodes[record["index"]] = record
        count = len(episodes)
        summary = dict(
            event="collection_status",
            workflow=args.workflow,
            status=m["status"],
            task_states=states,
            checkpointed_episodes=count,
            expected=1000,
            duration_s=m.get("duration"),
            updated_utc=datetime.now(timezone.utc).isoformat(),
        )
        print(json.dumps(summary), flush=True)
        (cache / "observed-progress.json").write_text(
            json.dumps(summary, indent=2) + "\n"
        )
        signature = (count, m["status"], tuple(sorted(states.items())))
        if signature != previous and (time.time() - last_publish >= 120 or terminal):
            status = json.loads(status_file.read_text())
            status["updated_utc"] = summary["updated_utc"]
            status["stages"][1] = dict(
                stage="Collection",
                status=f"{m['status']}: {args.workflow}",
                detail=f"At least {count:,} of 1,000 accepted episodes are visible in storage checkpoints. Worker states: {states}. Checkpoints lag active simulation by up to five minutes.",
            )
            status_file.write_text(json.dumps(status, indent=2) + "\n")
            run(
                [
                    sys.executable,
                    str(Path(__file__).with_name("publish_progress.py")),
                    str(status_file),
                ]
            )
            files = [
                "particle_gnn_development.html",
                "assets/particle-gnn/campaign-status.json",
                "assets/particle-gnn/source.zip",
            ]
            diff = run(["git", "-C", str(site), "diff", "--quiet", "--", *files])
            if diff.returncode == 1:
                commit = run(
                    [
                        "git",
                        "-C",
                        str(site),
                        "commit",
                        "--only",
                        "-m",
                        f"Update collection progress: {count} checkpointed episodes",
                        "--",
                        *files,
                    ]
                )
                if commit.returncode == 0:
                    pushed = run(["git", "-C", str(site), "push", "origin", "main"])
                    print(
                        json.dumps(
                            dict(
                                event="website_push",
                                returncode=pushed.returncode,
                                detail=pushed.stdout[-300:],
                            )
                        ),
                        flush=True,
                    )
                else:
                    print(
                        json.dumps(
                            dict(
                                event="website_commit_error",
                                detail=commit.stdout[-500:],
                            )
                        ),
                        flush=True,
                    )
            last_publish = time.time()
            previous = signature
        if terminal:
            return 0 if m["status"] == "COMPLETED" else 1
        time.sleep(args.interval)


if __name__ == "__main__":
    sys.exit(main())

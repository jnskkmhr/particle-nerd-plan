"""Create a lossless post-settlement playback file with two history frames.

Particle arrays retain the full inference window. Rigid states and forces keep
their original 200 Hz indexing, so the existing play.py input format is preserved.
"""

import argparse
import json
from pathlib import Path

import h5py
import numpy as np


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("source", type=Path)
    parser.add_argument("output", type=Path)
    args = parser.parse_args()
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with h5py.File(args.source, "r") as source, h5py.File(args.output, "x") as out:
        manifest = json.loads(source.attrs["manifest"])
        frames = source["frame_steps"][:]
        settled_frame = int(np.searchsorted(frames, manifest["settled_step"]))
        start = max(0, settled_frame - 2)
        manifest["demo_excerpt"] = dict(
            source_file=args.source.name,
            first_original_particle_frame=start,
            note="Lossless particle playback excerpt; two pre-settlement history frames and the complete subsequent interaction",
        )
        for key, value in source.attrs.items():
            out.attrs[key] = value
        out.attrs["manifest"] = json.dumps(manifest)
        for key, dataset in source.items():
            values = dataset[start:] if key in ("frame_steps", "particle_position", "particle_velocity") else dataset[:]
            out.create_dataset(key, data=values, compression="gzip", compression_opts=4, shuffle=True)
    print(json.dumps(dict(file=str(args.output), bytes=args.output.stat().st_size, initial_history_frames=settled_frame-start)))


if __name__ == "__main__":
    main()

"""Independently check recorded timing, physical balance, and perturbation laws."""

import json
from pathlib import Path

import h5py
import numpy as np
from scipy.spatial.transform import Rotation

root=Path(__file__).resolve().parents[2]
data=root/"particle_nerd_plan/results/particle_gnn_preview_v1"
results=[]
for case in ("rest","push-spin","drag-lift"):
    m=json.loads((data/f"{case}.json").read_text())
    with h5py.File(data/f"{case}.hdf5","r") as f:
        n=m["particle_count"]
        assert n==16384 and not m["scene"]["container_walls"]
        assert f["particle_position"].shape==f["particle_velocity"].shape
        for key in f:
            for start in range(0,len(f[key]),16):
                assert np.isfinite(f[key][start:start+16]).all(),(case,key,start)
        steps=f["frame_steps"][:]
        assert np.all(np.diff(steps)==4)
        assert np.count_nonzero(steps>=m["settled_step"])==251
        q=f["body_pose"][:]
        v=f["body_velocity"][:]
        ext=f["external_wrench"][:]
        applied=f["applied_feedback_wrench"][:]
        expected=f["material_on_body_wrench"][:]
        np.testing.assert_allclose(np.linalg.norm(q[:,3:],axis=1),1.,atol=1e-5)
        assert np.max(np.abs(ext[:m["settled_step"]]))==0
        np.testing.assert_allclose(applied[1:],expected[:-1],atol=1e-3,rtol=1e-4)
        residual=1.5*np.diff(v[:,:3],axis=0)/m["dt"]-applied[:,:3]-ext[:,:3]-[0.,0.,-14.715]
        residual_max=float(np.linalg.norm(residual,axis=1).max())
        assert residual_max<1e-3,(case,residual_max)
        settled=m["settled_step"]
        assert np.all(np.linalg.norm(v[settled-59:settled+1,:3],axis=1)<.02)
        assert np.all(np.linalg.norm(v[settled-59:settled+1,3:],axis=1)<.2)
        predicted=np.zeros_like(ext)
        if case=="push-spin":
            t=(np.arange(len(ext))-settled)*m["dt"]
            for pulse in m["pulses"]:
                phase=(t-pulse["start"])/pulse["duration"]
                active=(phase>0)&(phase<1)
                predicted[active]+=np.sin(np.pi*phase[active,None])**2*np.asarray(pulse["wrench"])
        elif case=="drag-lift":
            drag=m["drag"]
            arm=Rotation.from_quat(q[:-1,3:]).apply(drag["anchor_local_m"])
            origin=q[settled,:3]+arm[settled]
            t=(np.arange(len(ext))-settled)*m["dt"]
            active=(t>=.5)&(t<4.8)
            offset=np.column_stack([np.interp(t,drag["times"],np.asarray(drag["offsets_m"])[:,k]) for k in range(3)])
            point_velocity=v[:-1,:3]+np.cross(v[:-1,3:],arm)
            force=150*(origin+offset-q[:-1,:3]-arm)-6*point_velocity
            force*=np.minimum(1,45/np.maximum(np.linalg.norm(force,axis=1),1e-10))[:,None]
            predicted[active,:3]=force[active]
            predicted[active,3:]=np.cross(arm[active],force[active])
        np.testing.assert_allclose(ext,predicted,atol=5e-5,rtol=2e-5)
        results.append(dict(case=case,passed=True,states_50Hz=len(steps),post_settlement_states_50Hz=251,
                            max_body_force_balance_residual_N=residual_max))
output=root/"particle_nerd_plan/assets/particle-gnn/validation.json"
output.write_text(json.dumps(results,indent=2)+"\n")
print(json.dumps(results,indent=2))
